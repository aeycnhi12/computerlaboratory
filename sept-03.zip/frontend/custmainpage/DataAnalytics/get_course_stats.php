<?php
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$pass = "";
$db   = "history_db";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

/*
   Group by course + year. Handles blanks/nulls gracefully.
   Example label: "BSIT (2025)"
*/
$sql = "
    SELECT
        CASE
            WHEN course IS NULL OR TRIM(course) = '' THEN 'Unknown Course'
            ELSE course
        END AS course_label,
        CASE
            WHEN year IS NULL OR TRIM(year) = '' THEN 'Unknown'
            ELSE year
        END AS year_label,
        COUNT(*) AS borrow_count
    FROM history
    GROUP BY course_label, year_label
    ORDER BY borrow_count DESC
";

$result = $conn->query($sql);

$data = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $label = $row['course_label'] . " (" . $row['year_label'] . ")";
        $data[] = [
            'label' => $label,
            'count' => (int)$row['borrow_count']
        ];
    }
}

echo json_encode($data);
$conn->close();
