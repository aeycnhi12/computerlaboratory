<?php
session_start();

// Connections
$conn = new mysqli("localhost", "root", "", "cust_db");
$fhistoryconn = new mysqli("localhost", "root", "", "fhistory_db");

if ($conn->connect_error || $fhistoryconn->connect_error) {
    die("Connection failed.");
}

// Get RFID code
$rfidCode = $_POST['rfid_uid'] ?? '';

// Validate RFID first
$stmt = $conn->prepare("SELECT * FROM cust WHERE rfid_uid = ?");
$stmt->bind_param("s", $rfidCode);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $custData = $result->fetch_assoc();
    $facultyID = $custData['user_id'];
    $userType  = $custData['user_type'];

    // Restrict only faculty
    if ($userType !== 'faculty') {
        echo "<script>alert('Only faculty are allowed to borrow equipment.'); window.location.href = 'facu_borpage.php';</script>";
        exit();
    }

    // Check if faculty is banned
    if ($custData['ban_status'] === 'Banned') {
        echo "<script>alert('You are banned from borrowing. Please contact the administrator.'); window.location.href = 'facu_borpage.php';</script>";
        exit();
    }


    // Now check for unresolved penalties
    $penaltyCheck = $fhistoryconn->prepare("SELECT id FROM fhistory WHERE facultyID = ? AND penalty_status IN ('Pending', 'For Payment')");
    $penaltyCheck->bind_param("s", $facultyID);
    $penaltyCheck->execute();
    $penaltyResult = $penaltyCheck->get_result();

    if ($penaltyResult->num_rows > 0) {
        echo "<script>alert('You have unresolved penalties. Please settle them before borrowing again.'); window.location.href = 'facu_borpage.php';</script>";
        exit();
    }


    // Proceed to Save Borrow Record
    $fborrowConn = new mysqli("localhost", "root", "", "fborrow_db");

    $lastname = $_POST['lastname'];
    $firstname = $_POST['firstname'];
    $equipment = $_POST['equipment'];
    $serialnum = $_POST['serialnum'];
    $equip_rfid = $_POST['equip_rfid'];
    $quantity = $_POST['quantity'];
    $currentDate = $_POST['currentDate'];
    $currentTime = $_POST['currentTime'];
    $due_date = $_POST['due_date'];
    $due_time = $_POST['due_time'];
    $status = 'Unreturned';

    $insert = $fborrowConn->prepare("INSERT INTO fborrow (facultyID, lastname, firstname, equipment, serialnum, equip_rfid, quantity, currentDate, currentTime, due_date, due_time, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $insert->bind_param("ssssssssssss", $facultyID, $lastname, $firstname, $equipment, $serialnum, $equip_rfid, $quantity, $currentDate, $currentTime, $due_date, $due_time, $status);
    $insert->execute();

    echo "<script>alert('Borrow Saved Successfully!'); window.location.href='../facumainpage/facumain_page.php';</script>";

} else {
    // Invalid RFID
    echo "<script>alert('Invalid RFID! Please try again.'); window.history.back();</script>";
}
?>
