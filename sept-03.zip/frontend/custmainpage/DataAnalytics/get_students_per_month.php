<?php
$host = "localhost";
$user = "root";
$pass = "";

// Connect to history_db
$conn = new mysqli($host, $user, $pass, "history_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query: count unique students per month
$sql = "SELECT DATE_FORMAT(currentDate, '%Y-%m') AS month, COUNT(DISTINCT facultyID) AS student_count
        FROM fhistory
        GROUP BY month
        ORDER BY month ASC";

$result = $conn->query($sql);

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = [
        'month' => $row['month'],
        'count' => (int)$row['student_count']
    ];
}

header('Content-Type: application/json');
echo json_encode($data);

$conn->close();
?>
