<?php
$conn = new mysqli("localhost", "root", "", "equip_db");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate inputs
    $equip_name = trim($_POST['equip_name'] ?? '');
    $rfid_tag   = trim($_POST['rfid_tag'] ?? '');
    $qty        = intval($_POST['qty'] ?? 0);

    if ($equip_name === '' || $rfid_tag === '' || $qty <= 0) {
        echo "<script>alert('Error: Please fill in all fields correctly!'); window.history.back();</script>";
        exit;
    }

    // ✅ Check if RFID already exists
    $check = $conn->prepare("SELECT id FROM equip WHERE rfid_tag = ?");
    $check->bind_param("s", $rfid_tag);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Error: RFID already recorded on another equipment!'); window.history.back();</script>";
        exit;
    }

    // ✅ Check if equipment name already exists (optional)
    $checkName = $conn->prepare("SELECT id FROM equip WHERE equip_name = ?");
    $checkName->bind_param("s", $equip_name);
    $checkName->execute();
    $nameResult = $checkName->get_result();

    if ($nameResult->num_rows > 0) {
        echo "<script>alert('Error: Equipment name already exists!'); window.history.back();</script>";
        exit;
    }

    // Insert new equipment
    $stmt = $conn->prepare("INSERT INTO equip (equip_name, equip_rfid, qty, available_qty) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssii", $equip_name, $rfid_tag, $qty, $qty);

    if ($stmt->execute()) {
        echo "<script>alert('Equipment successfully added!'); window.location='manageequipment.php';</script>";
    } else {
        echo "<script>alert('Database error while saving equipment.'); window.history.back();</script>";
    }
}
?>
