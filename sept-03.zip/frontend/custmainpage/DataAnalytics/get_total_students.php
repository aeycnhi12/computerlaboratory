<?php
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$pass = "";
$db   = "cust_db";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$sql = "SELECT COUNT(*) AS total_students FROM cust WHERE LOWER(user_type) = 'student'";
$result = $conn->query($sql);

$data = ["count" => 0];
if ($result && $row = $result->fetch_assoc()) {
    $data["count"] = (int)$row["total_students"];
}

echo json_encode($data);
$conn->close();
?>
