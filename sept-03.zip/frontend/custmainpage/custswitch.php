<?php
session_start();
if (!isset($_SESSION['custodian_name'])) {
    header("Location: ../loginpage/clogin_page.php");
    exit();
}
$custodianName = $_SESSION['custodian_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta naQme="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Custodian Main Page</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
  <link href="CustodianSwitch.css" rel="stylesheet">
</head>
<body>

<div class="bg-overlay"></div>
  <div class="fade-in-overlay"></div>
  <div class="fade-out-overlay" id="fadeOutOverlay"></div>

  <div class="center-box">
    <h1>Select Borrowed List Type</h1>
    
<div class="button-grid">
  <div class="tooltip">
    <button id="stulistBtn">STUDENT<br>BORROWED LIST</button>
    <span class="tooltiptext">View a list of items borrowed by students.</span>
  </div>
  <div class="tooltip">
    <button id="faculistBtn">FACULTY<br>BORROWED LIST</button>
    <span class="tooltiptext">View a list of items borrowed by faculty members.</span>
  </div>
</div>

     <a href="../custmainpage/custmain_page.php" class="back-button">← Back</a>

  </div>

  <script>
stulistBtn.addEventListener('click', function () {
  fadeOutOverlay.classList.add('active');
  setTimeout(() => {
    window.location.href = '../custlistaccount/stu_borrow_list.php';
  }, 800);
});

faculistBtn.addEventListener('click', function () {
  fadeOutOverlay.classList.add('active');
  setTimeout(() => {
    window.location.href = '../custlistaccount/facu_borrow_list.php';
  }, 800);
});
        

  </script>
</body>
</html>
