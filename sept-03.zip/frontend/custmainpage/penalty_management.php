<?php
session_start();

$conn = new mysqli("localhost", "root", "", "cust_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_POST['id'] ?? null;
$action = $_POST['action'] ?? null;
$penalty_amount = $_POST['penalty_amount'] ?? null;
$userType = $_POST['userType'] ?? null;
$filterCondition = $_GET['condi_tion'] ?? '';
$conditionSql = $filterCondition ? "AND condi_tion = '$filterCondition'" : "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && $action && $id && $userType) {
    if ($userType === 'student') {
        $historyConn = new mysqli("localhost", "root", "", "history_db");
        $fetchSql = "SELECT studentID FROM history WHERE id = ?";
    } elseif ($userType === 'faculty') {
        $historyConn = new mysqli("localhost", "root", "", "fhistory_db");
        $fetchSql = "SELECT facultyID as studentID FROM fhistory WHERE id = ?";
    }

    if (isset($historyConn) && !$historyConn->connect_error) {
        $fetchStmt = $historyConn->prepare($fetchSql);
        $fetchStmt->bind_param("i", $id);
        $fetchStmt->execute();
        $fetchResult = $fetchStmt->get_result();

        if ($fetchResult->num_rows === 1) {
            $userData = $fetchResult->fetch_assoc();
            $userID = $userData['studentID'];

            if ($action === 'Disregard') {
                $banUpdate = $conn->prepare("UPDATE cust SET ban_status = 'Banned' WHERE user_id = ?");
                $banUpdate->bind_param("s", $userID);
                $banUpdate->execute();
                $banUpdate->close();

                $updateSql = $userType === 'student' ?
                    "UPDATE history SET penalty_status = 'Disregarded' WHERE id = ?" :
                    "UPDATE fhistory SET penalty_status = 'Disregarded' WHERE id = ?";

                $updateStmt = $historyConn->prepare($updateSql);
                $updateStmt->bind_param("i", $id);
                $updateStmt->execute();
                $updateStmt->close();
            }

            if ($action === 'ApplyPenalty' && $penalty_amount !== null) {
                $updateSql = $userType === 'student' ?
                    "UPDATE history SET penalty_amount = ?, penalty_status = 'For Payment' WHERE id = ?" :
                    "UPDATE fhistory SET penalty_amount = ?, penalty_status = 'For Payment' WHERE id = ?";

                $updateStmt = $historyConn->prepare($updateSql);
                $updateStmt->bind_param("di", $penalty_amount, $id);
                $updateStmt->execute();
                $updateStmt->close();
            }

            if ($action === 'Paid') {
                $updateSql = $userType === 'student' ?
                    "UPDATE history SET penalty_status = 'Paid' WHERE id = ?" :
                    "UPDATE fhistory SET penalty_status = 'Paid' WHERE id = ?";

                $updateStmt = $historyConn->prepare($updateSql);
                $updateStmt->bind_param("i", $id);
                $updateStmt->execute();
                $updateStmt->close();
            }

            if ($action === 'Replace') {
                $updateSql = $userType === 'student' ?
                    "UPDATE history SET penalty_status = 'Replace Item' WHERE id = ?" :
                    "UPDATE fhistory SET penalty_status = 'Replace Item' WHERE id = ?";

                $updateStmt = $historyConn->prepare($updateSql);
                $updateStmt->bind_param("i", $id);
                $updateStmt->execute();
                $updateStmt->close();
            }

            if ($action === 'Unban') {
                $unbanUpdate = $conn->prepare("UPDATE cust SET ban_status = 'Active' WHERE user_id = ?");
                $unbanUpdate->bind_param("s", $userID);
                $unbanUpdate->execute();
                $unbanUpdate->close();
            }

            if ($action === 'Remove') {
                $deleteSql = $userType === 'student' ?
                    "DELETE FROM history WHERE id = ?" :
                    "DELETE FROM fhistory WHERE id = ?";

                $deleteStmt = $historyConn->prepare($deleteSql);
                $deleteStmt->bind_param("i", $id);
                $deleteStmt->execute();
                $deleteStmt->close();
            }
        }

        $fetchStmt->close();
        $historyConn->close();
    }
}

$historyConn = new mysqli("localhost", "root", "", "history_db");
$studentPenalties = $historyConn->query("SELECT *, 'student' as userType FROM history WHERE penalty_status IN ('Pending', 'For Payment', 'Disregarded') $conditionSql");
$historyConn->close();

$fhistoryConn = new mysqli("localhost", "root", "", "fhistory_db");
$facultyPenalties = $fhistoryConn->query("SELECT *, 'faculty' as userType FROM fhistory WHERE penalty_status IN ('Pending', 'For Payment', 'Disregarded') $conditionSql");
$fhistoryConn->close();

$allPenalties = array_merge(
    $studentPenalties ? $studentPenalties->fetch_all(MYSQLI_ASSOC) : [],
    $facultyPenalties ? $facultyPenalties->fetch_all(MYSQLI_ASSOC) : []
);

// Fetch Ban Status
$userIDs = [];
foreach ($allPenalties as $row) {
    $userIDs[] = $row['userType'] === 'faculty' ? $row['facultyID'] : $row['studentID'];
}
$banStatus = [];
if (!empty($userIDs)) {
    $placeholders = implode(",", array_fill(0, count($userIDs), "?"));
    $types = str_repeat("s", count($userIDs));

    $banStmt = $conn->prepare("SELECT user_id, ban_status FROM cust WHERE user_id IN ($placeholders)");
    $banStmt->bind_param($types, ...$userIDs);
    $banStmt->execute();
    $banResult = $banStmt->get_result();
    while ($row = $banResult->fetch_assoc()) {
        $banStatus[$row['user_id']] = $row['ban_status'];
    }
    $banStmt->close();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Penalty Management</title>
    <link rel="stylesheet" href="penaltymanagement.css">
</head>
<body>
    <div class="fade-in-overlay"></div>
  <div class="fade-out-overlay" id="fadeOutOverlay"></div>
  


    <div class="container-box">
        <a href="penaltyhistory.php" class="view-history-btn">View Completed Penalties</a>
    <h1>Penalty Management</h1>
    <div class="filter-wrapper">
  <form method="GET" id="filterForm">
      <label for="conditionFilter">Filter by Condition:</label>
      <select name="condi_tion" id="conditionFilter" onchange="this.form.submit();">
          <option value="" <?= (!isset($_GET['condi_tion']) || $_GET['condi_tion'] == '') ? 'selected' : '' ?>>All</option>
          <option value="Good" <?= (isset($_GET['condi_tion']) && $_GET['condi_tion'] == 'Good') ? 'selected' : '' ?>>Good</option>
          <option value="Overdue" <?= (isset($_GET['condi_tion']) && $_GET['condi_tion'] == 'Overdue') ? 'selected' : '' ?>>Overdue</option>
          <option value="Damaged" <?= (isset($_GET['condi_tion']) && $_GET['condi_tion'] == 'Damaged') ? 'selected' : '' ?>>Damaged</option>
          <option value="Lost" <?= (isset($_GET['condi_tion']) && $_GET['condi_tion'] == 'Lost') ? 'selected' : '' ?>>Lost</option>
      </select>
  </form>
</div>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>User Type</th>
            <th>Name</th>
            <th>Equipment</th>
            <th>Condition</th>
            <th>Comment</th>
            <th>Penalty Amount</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($allPenalties as $row):
            $userIDKey = $row['userType'] === 'faculty' ? $row['facultyID'] : $row['studentID'];
            $ban = $banStatus[$userIDKey] ?? 'Active';
        ?>
        <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= ucfirst($row['userType']) ?></td>
            <td><?= htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) ?></td>
            <td><?= htmlspecialchars($row['equipment']) ?></td>
            <td><?= htmlspecialchars($row['condi_tion']) ?></td>
            <td><?= htmlspecialchars($row['comment']) ?></td>
            <td><?= $row['penalty_amount'] ? '₱' . number_format($row['penalty_amount'], 2) : '---' ?></td>
            <td><?= htmlspecialchars($row['penalty_status']) ?></td>
            <td>
                <form method="POST" style="display:inline-block;">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="hidden" name="userType" value="<?= $row['userType'] ?>">
                    <input type="hidden" name="action" value="Disregard">
                    <button type="submit" onclick="return confirm('Disregard and Ban this user?');">Flag</button>
                </form>

                <?php if ($row['penalty_status'] === 'Pending'): ?>
                <form method="POST" style="display:inline-block;" onsubmit="return confirmPaid(this);">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="hidden" name="userType" value="<?= $row['userType'] ?>">
                    <input type="hidden" name="action" value="ApplyPenalty">
                    <input type="number" name="penalty_amount" placeholder="Amount" required>
                    <button type="submit">Apply Penalty</button>
                </form>
                <?php endif; ?>

                <?php if ($row['penalty_status'] === 'For Payment'): ?>
                <form method="POST" style="display:inline-block;" onsubmit="return confirm('Confirm payment completed?');">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="hidden" name="userType" value="<?= $row['userType'] ?>">
                    <input type="hidden" name="action" value="Paid">
                    <button type="submit">Mark Paid</button>
                </form>
                <?php endif; ?>

                <form method="POST" style="display:inline-block;" onsubmit="return confirm('Request replacement?');">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="hidden" name="userType" value="<?= $row['userType'] ?>">
                    <input type="hidden" name="action" value="Replace">
                    <button type="submit">Replace</button>
                </form>

                <?php if ($row['penalty_status'] === 'Disregarded' && $ban === 'Banned'): ?>
                    <form method="POST" style="display:inline-block;" onsubmit="return confirm('Unban this user?');">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <input type="hidden" name="userType" value="<?= $row['userType'] ?>">
                        <input type="hidden" name="action" value="Unban">
                        <button type="submit">Unban</button>
                    </form>
                <?php endif; ?>

                <form method="POST" style="display:inline-block;" onsubmit="return confirm('Remove this record permanently?');">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <input type="hidden" name="userType" value="<?= $row['userType'] ?>">
                    <input type="hidden" name="action" value="Remove">
                    <button type="submit">Remove Record</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>


  <a href="../custmainpage/custmain_page.php" class="back-button">← Back</a>
<div class="wave-container">
    <div class="wave wave-back"></div>
    <div class="wave wave-middle"></div>
    <div class="wave wave-top"></div>
  </div>
  <div class="circle-container" id="circleContainer"></div>
    <script>
      const circleImages = [
    'fpp_circle1.png',
    'fpp_circle2.png',
    'fpp_circle3.png',
    'fpp_circle4.png',
    'fpp_circle5.png',
    'fpp_circle6.png',
    'fpp_circle7.png'
  ];

  function getWeightedSize() {
    const rand = Math.random();
    if (rand < 0.6) return Math.floor(Math.random() * 20) + 20;
    if (rand < 0.9) return Math.floor(Math.random() * 20) + 40;
    return Math.floor(Math.random() * 13) + 60;
  }

  function createFloatingCircle() {
    const container = document.getElementById('circleContainer');
    const circle = document.createElement('div');
    const randomImg = circleImages[Math.floor(Math.random() * circleImages.length)];
    circle.style.backgroundImage = `url('${randomImg}')`;
    const size = getWeightedSize();
    circle.style.width = `${size}px`;
    circle.style.height = `${size}px`;
    const maxLeft = window.innerWidth - size;
    circle.style.left = `${Math.random() * maxLeft}px`;
    const duration = Math.random() * 3 + 4;
    circle.style.animationDuration = `${duration}s`;
    circle.classList.add('floating-circle');
    container.appendChild(circle);
    setTimeout(() => {
      circle.remove();
    }, duration * 1000);
  }

  function spawnFewCircles() {
    const count = Math.random() < 0.7 ? 1 : 2;
    for (let i = 0; i < count; i++) {
      createFloatingCircle();
    }
  }

  function scheduleSpawn() {
    spawnFewCircles();
    setTimeout(scheduleSpawn, Math.random() * 1500 + 2000);
  }

  scheduleSpawn();
        function confirmPaid(form) {
            const amount = form.penalty_amount.value;
            if (amount === '' || isNaN(amount)) {
                alert('Please enter a valid penalty amount.');
                return false;
            }
            return confirm(`Apply penalty of ₱${amount}?`);
        }
    </script>
    
</body>
</html>

<?php $conn->close(); ?>
