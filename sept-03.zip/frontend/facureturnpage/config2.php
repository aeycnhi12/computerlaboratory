<?php
// Connection to fborrow_db
$fborrowConn = new mysqli("localhost", "root", "", "fborrow_db");
if ($fborrowConn->connect_error) {
    die("Connection to fborrow_db failed: " . $fborrowConn->connect_error);
}

// Connection to fhistory_db
$fhistoryConn = new mysqli("localhost", "root", "", "fhistory_db");
if ($fhistoryConn->connect_error) {
    die("Connection to fhistory_db failed: " . $fhistoryConn->connect_error);
}
?>
