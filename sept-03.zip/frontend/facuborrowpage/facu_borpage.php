<?php
session_start();
date_default_timezone_set('Asia/Manila');

$conn = new mysqli("localhost", "root", "", "equip_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
SELECT 
    e.name,
    e.equip_rfid,
    e.serialnum,
    e.quantity AS total_qty,
    (
        IFNULL((SELECT SUM(quantity) FROM borrow_db.borrow WHERE equipment = e.name AND status = 'Unreturned'), 0) +
        IFNULL((SELECT SUM(quantity) FROM fborrow_db.fborrow WHERE equipment = e.name AND status = 'Unreturned'), 0)
    ) AS total_borrowed,
    (e.quantity - (
        IFNULL((SELECT SUM(quantity) FROM borrow_db.borrow WHERE equipment = e.name AND status = 'Unreturned'), 0) +
        IFNULL((SELECT SUM(quantity) FROM fborrow_db.fborrow WHERE equipment = e.name AND status = 'Unreturned'), 0)
    )) AS available_qty
FROM equip_db.equip e
WHERE e.status = 'Available'
HAVING available_qty > 0
";

$result = $conn->query($sql);

// Name splitting logic
if (isset($_SESSION['faculty_name'])) {
    $fullName = trim($_SESSION['faculty_name']);
    $nameParts = explode(' ', $fullName);
    $lastName = array_pop($nameParts); // Get last word = last name
    $firstName = implode(' ', $nameParts); // Rest = first name
    $_SESSION['lastname'] = $lastName;
    $_SESSION['firstname'] = $firstName;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Borrow Equipment</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="FacultyBorrowEquipment.css">
</head>
<body>
  <div class="bg2"></div>
  <div class="bg3"></div>
  <div class="bg4"></div>
  <div class="fade-in-overlay"></div>
  <div class="fade-out-overlay" id="fadeOutOverlay"></div>

  <form action="facu_bor_save.php" method="POST" class="center-box" id="borrowForm">
    <h1>Borrow Equipment</h1>
    <h3>Please fill the information here</h3>

   <div class="form-container">
  <div class="form-section personal-info">
    <h2 class="section-title">Personal Information</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="id">ID</label>
        <input type="text" id="id" name="id" value="<?= htmlspecialchars($_SESSION['id'] ?? '') ?>" readonly>
      </div>
      <div class="form-group">
        <label for="facultyID">Faculty ID</label>
        <input type="text" id="facultyID" name="facultyID" value="<?= htmlspecialchars($_SESSION['faculty_id'] ?? '') ?>" readonly>
      </div>
    </div>
    <div class="form-group-row">
  <div class="form-group">
    <label for="lastname">Last Name</label>
    <input type="text" id="lastname" name="lastname" value="<?= htmlspecialchars($_SESSION['lastname'] ?? '') ?>" readonly>
  </div>
  <div class="form-group">
    <label for="firstname">First Name</label>
    <input type="text" id="firstname" name="firstname" value="<?= htmlspecialchars($_SESSION['firstname'] ?? '') ?>" readonly>
  </div>
</div>
  </div>

  <div class="vertical-separator"></div>

  <div class="form-section handler-section">
    <h2 class="section-title">Deadline Information</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="handled">Time</label>
        <input type="text" id="currentTime" name="currentTime" value="<?= htmlspecialchars($_SESSION['currentTime'] ?? '') ?>" readonly>
      </div>
       <div class="form-group">
        <label for="currentTime">Date</label>
        <input type="text" id="currentDate" name="currentDate" value="<?= htmlspecialchars($_SESSION['currentDate'] ?? '') ?>" readonly>
      </div>
    </div>
    <div class="form-group-row">
  <div class="form-group">
    <label for="due_date">Due Date</label>
    <input type="text" id="due_date" name="due_date" value="<?= htmlspecialchars($_SESSION['due_date'] ?? '') ?>" readonly>
  </div>
  <div class="form-group">
    <label for="due_time">Due Time</label>
    <input type="text" id="due_time" name="due_time" value="<?= htmlspecialchars($_SESSION['due_time'] ?? '') ?>" readonly>
  </div>
</div>
  </div>
</div>


  <div class="form-section item-info">
    <h2 class="section-title">Equipment Information</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="equip_rfid">Equipment RFID</label>
        <input type="text" name="equip_rfid" id="equip_rfid" required placeholder="Tap Equipment RFID">
      </div>
      <div class="form-group">
        <label for="equipment">Equipment Name</label>
        <input type="text" id="equipment" name="equipment" readonly required>
      </div>
      <div class="form-group">
        <label for="serialnum">Serial Number</label>
        <input type="text" id="serialnum" name="serialnum" value="<?= htmlspecialchars($_SESSION['serialnum'] ?? '') ?>" readonly>
      </div>
      <div class="form-group">
        <label for="quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" value="<?= htmlspecialchars($_SESSION['quantity'] ?? '') ?>" min="1">
      </div>
    </div>
  </div>

<div class="rfid-section">
  <p id="tapRFIDText" style="cursor: pointer; color: gray; font-weight: bold; font-style: italic; margin: 0; padding: 0; line-height: 1;">
    Click here then Tap your RFID to borrow when finished.
  </p>
  <input type="text" id="rfidInput" name="rfid_uid" style="opacity: 0; position: absolute; pointer-events: none;">
</div>
</form>

    <div class="button-group">
    <a href="../facumainpage/facumain_page.php" class="back-button">BACK</a>
  </div>
  </form>
  <!-- Rules & Regulations Modal -->
<div id="rulesModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; 
    background:rgba(0,0,0,0.6); justify-content:center; align-items:center;">
    <div style="background:#fff; padding:20px; width:400px; border-radius:10px; text-align:center;">
        <h3>Rules & Regulations</h3>
        <ol>
  <li>
    <strong>Proper Use Only</strong>
    <ul>
      <li>Equipment must be used only for academic or authorized purposes.</li>
    </ul>
  </li>
  <li>
    <strong>Return on Time</strong>
    <ul>
      <li>All borrowed equipment must be returned on or before the due time/date.</li>
    </ul>
  </li>
  <li>
    <strong>Handle with Care</strong>
    <ul>
      <li>Borrowers are responsible for handling the equipment properly and preventing damage.</li>
    </ul>
  </li>
  <li>
    <strong>Report Issues Immediately</strong>
    <ul>
      <li>Any malfunction, damage, or missing parts must be reported immediately to the custodian.</li>
    </ul>
  </li>
  <li>
    <strong>Liability for Damages</strong>
    <ul>
      <li>Borrowers will be held accountable for damages or loss of equipment.</li>
    </ul>
  </li>
  <li>
    <strong>No Unauthorized Transfer</strong>
    <ul>
      <li>Borrowed equipment must not be lent to another person without permission.</li>
    </ul>
  </li>
  <li>
    <strong>Penalties</strong>
    <ul>
      <li>Late returns, damages, or violations may result in penalties, suspension of borrowing privileges, or disciplinary action.</li>
    </ul>
  </li>
</ol>

        <br>
        <button id="agreeBtn">I Agree</button>
        <button id="cancelBtn">Cancel</button>
    </div>

  <script>
     window.addEventListener('beforeunload', function () {
    const fadeOutOverlay = document.getElementById('fadeOutOverlay');
    if (fadeOutOverlay) {
      fadeOutOverlay.classList.add('active');
    }
  });

  window.addEventListener('load', function () {
    const fadeInOverlay = document.querySelector('.fade-in-overlay');
    if (fadeInOverlay) {
      fadeInOverlay.style.animation = 'fadeInOverlay 0.8s ease-in-out forwards';
    }
  });

  const backButton = document.querySelector('.back-button');
  const fadeOutOverlay = document.getElementById('fadeOutOverlay');

  if (backButton) {
    backButton.addEventListener('click', (e) => {
      e.preventDefault();
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = backButton.getAttribute('href');
      }, 800);
    });
  }
  const equipmentNameInput = document.getElementById('equipment');
const serialNumberInput = document.getElementById('serialnum');
const equipRFIDInput = document.getElementById('equip_rfid');
const rfidText = document.getElementById('tapRFIDText');
const rfidInput = document.getElementById('rfidInput');
const rulesModal = document.getElementById("rulesModal");
const agreeBtn   = document.getElementById("agreeBtn");
const cancelBtn  = document.getElementById("cancelBtn");


// Disable Student RFID initially
rfidText.style.pointerEvents = 'none';
rfidText.style.color = 'gray';
rfidText.innerText = 'Please scan Equipment RFID first.';

window.onload = function () {
  const dateInput = document.getElementById('currentDate');
  const timeInput = document.getElementById('currentTime');
  const dueDateInput = document.getElementById('due_date');
  const dueTimeInput = document.getElementById('due_time');

  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  dateInput.value = `${year}-${month}-${day}`;

  let hours = now.getHours();
  let minutes = now.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12 || 12;
  minutes = minutes < 10 ? '0' + minutes : minutes;
  timeInput.value = `${hours}:${minutes} ${ampm}`;

  const dueDate = new Date(now);
  dueDate.setDate(dueDate.getDate() + 0);
  dueDateInput.value = `${dueDate.getFullYear()}-${String(dueDate.getMonth() + 1).padStart(2, '0')}-${String(dueDate.getDate()).padStart(2, '0')}`;

  dueTimeInput.value = '4:00 PM';

  equipRFIDInput.focus();
};

equipRFIDInput.addEventListener('focus', function() {
    equipRFIDInput.value = '';
});

equipRFIDInput.addEventListener('input', function() {
  const rfidValue = this.value.trim();
  if (rfidValue.length >= 10) {
    fetch(`fetch_equipment.php?rfid_uid=${rfidValue}`)
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          alert('Equipment not found!');
          equipmentNameInput.value = '';
          serialNumberInput.value = '';
          rfidText.style.pointerEvents = 'none';
          rfidText.style.color = 'gray';
          rfidText.innerText = 'Please scan Equipment RFID first.';
        } else {
          equipmentNameInput.value = data.name;
          serialNumberInput.value = data.serialnum;
          document.getElementById('quantity').value = '1';

          // Show Rules before enabling Faculty RFID
          rulesModal.style.display = "flex";

          // If Agree -> enable Faculty RFID
          agreeBtn.onclick = () => {
            rulesModal.style.display = "none";
            rfidText.style.pointerEvents = 'auto';
            rfidText.style.color = 'black';
            rfidText.innerText = 'Click here then Tap your Faculty RFID to borrow.';
          };

          // If Cancel -> reset equipment
          cancelBtn.onclick = () => {
            rulesModal.style.display = "none";
            equipRFIDInput.value = '';
            equipmentNameInput.value = '';
            serialNumberInput.value = '';
            rfidText.style.pointerEvents = 'none';
            rfidText.style.color = 'gray';
            rfidText.innerText = 'Please scan Equipment RFID first.';
          };
        }
      })
      .catch(err => console.error(err));
  }
});

rfidText.addEventListener('click', function() {
  if (rfidText.style.pointerEvents === 'none') return;
  alert('Please tap your Faculty RFID card now.');
  rfidInput.focus();
});

rfidInput.addEventListener('input', function() {
  const rfidValue = this.value.trim();
  if (rfidValue.length >= 10) {
    console.log('Faculty RFID detected:', rfidValue);
    document.getElementById('borrowForm').submit();
  }
});

rfidInput.addEventListener('input', function() {
  const rfidValue = this.value.trim();
  if (rfidValue.length >= 10) {
    console.log('Faculty RFID detected:', rfidValue);

    // Check user type before submit
    fetch(`fetch_user.php?rfid_uid=${rfidValue}`)
      .then(res => res.json())
      .then(data => {
        if (data.error) {
          alert('Invalid RFID!');
        } else if (data.user_type !== 'faculty') {
          alert('Only faculty are allowed to borrow equipment.');
        } else {
          // Proceed with submit if valid faculty
          document.getElementById('borrowForm').submit();
        }
      })
      .catch(err => console.error('Fetch error:', err));
  }
});


  </script>
</body>
</html>
<?php $conn->close(); ?>
