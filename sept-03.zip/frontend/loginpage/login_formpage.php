<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="Login_FrontPage.css">
</head>
<body>
  <div class="logo-container">
    <img src="AULogo.png" alt="Main Logo" class="logo" />
    <img src="AULogo2.png" alt="Slogan Logo" class="slogan" />
    <img src="AULogo3.png" alt="Additional Slogan" class="sub-slogan" />
  </div>

  <div class="logo-top">
    <img src="AULogo.png" alt="New Main Logo" class="main" />
    <img src="Campus.png" alt="Campus Label" class="campus" />
  </div>

  <div class="center-box">
    <div class="login-left">
      <div class="profile-wrapper">
        <div class="profile-wrapper-inner">
          <div class="profile-icon"></div>
        </div>
      </div>
      <label for="userId">USER ID NO.</label>
      <input id="userId" type="text" placeholder="Enter User ID Here..." />
      <div class="hint">Example: 01-23456</div>
      <div class="hint-space"></div>
      <label for="userPass">USER PASSWORD</label>
      <input id="userPass" type="password" placeholder="Enter User PASSWORD Here..." />
      <div class="hint">Forget Password?</div>
      <button type="submit" name="login">Login</button>
    </div>
    <div class="separator"></div>
    <div class="right-panel">
      <div class="rfid-box">
        <div class="rfid-text">Please Scan Your<br>RFID Card To Log In.</div>
        <div class="rfid-image-wrapper">
          <div class="rfid-image-inner">
            <img src="RFIDLogo.png" alt="RFID Logo" />
          </div>
        </div>
      </div>
    </div>
  </div>

 <div class="popup-banner">
  <span class="popup-close" id="popupClose">&times;</span>
    <b>Please Select which User is being logged.</b><br>
    <div class="button-row">
      <a href="clogin_page.php" id="studentBtn"><button>CUSTODIAN</button></a>
      <a href="flogin_page.php" id="studentBtn"><button>FACULTY</button></a>
      <a href="slogin_page.php" id="studentBtn"><button>STUDENT</button></a>
    </div>
    <hr>
    <small><b>Note:</b> The following buttons only exist on the prototype to simulate either of the user logins.<br>It is <b>not indicative</b> of the final product.</small>
  </div>

  <div class="fade-overlay" id="fadeOverlay"></div>

  <script>
    const studentBtn = document.getElementById('studentBtn');
    const fadeOverlay = document.getElementById('fadeOverlay');

    studentBtn.addEventListener('click', function (e) {
      e.preventDefault();
      fadeOverlay.style.opacity = '1';
      fadeOverlay.style.pointerEvents = 'auto';
      setTimeout(() => {
        window.location.href = studentBtn.getAttribute('href');
      }, 800);
    });

    const facultyBtn = document.getElementById('studentBtn');
    facultyBtn.addEventListener('click', function (e) {
      e.preventDefault();
      fadeOverlay.style.opacity = '1';
      fadeOverlay.style.pointerEvents = 'auto';
      setTimeout(() => {
        window.location.href = studentBtn.getAttribute('href');
      }, 800);
    });

    const custodianBtn = document.getElementById('studentBtn');
    studentBtn.addEventListener('click', function (e) {
      e.preventDefault();
      fadeOverlay.style.opacity = '1';
      fadeOverlay.style.pointerEvents = 'auto';
      setTimeout(() => {
        window.location.href = studentBtn.getAttribute('href');
      }, 800);
    });

    const popupClose = document.getElementById('popupClose');
const popupBanner = document.querySelector('.popup-banner');

popupClose.addEventListener('click', () => {
  popupBanner.style.display = 'none';
});

  </script>

</body>
</html>
