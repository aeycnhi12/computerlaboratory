<?php
$conn = new mysqli("localhost", "root", "", "equip_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['rfid_uid'])) {
    $rfid_uid = $conn->real_escape_string($_GET['rfid_uid']);
    $sql = "SELECT name, serialnum FROM equip WHERE equip_rfid = '$rfid_uid' LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $row = $result->fetch_assoc()) {
        echo json_encode([
            'name' => $row['name'],
            'serialnum' => $row['serialnum']
        ]);
    } else {
        echo json_encode(['error' => 'Equipment not found']);
    }
}
$conn->close();
?>
