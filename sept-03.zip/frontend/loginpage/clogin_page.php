<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - Custodian</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="clogin_page.css" />
</head>
<body>
  <?php if (isset($_GET['msg']) && !empty($_GET['msg'])): ?>
<script>
    alert("<?php echo addslashes($_GET['msg']); ?>");
    // remove msg=... from URL so it won’t trigger on refresh
    if (window.history.replaceState) {
        const url = new URL(window.location.href);
        url.searchParams.delete('msg');
        window.history.replaceState({}, document.title, url.pathname);
    }
</script>
<?php endif; ?>


  <div class="logo-container">
    <img src="AULogo.png" alt="Main Logo" class="logo" />
    <img src="AULogo2.png" alt="Slogan Logo" class="slogan" />
    <img src="AULogo3.png" alt="Additional Slogan" class="sub-slogan" />
  </div>

  <div class="logo-top">
    <img src="AULogo.png" alt="New Main Logo" class="main" />
    <img src="Campus.png" alt="Campus Label" class="campus" />
  </div>

  <div class="center-box">

    <form class="login-left" action="clogin.php" method="POST">
      <div class="profile-wrapper">
        <div class="profile-wrapper-inner">
          <div class="profile-icon"></div>
        </div>
      </div>

      <label for="custodianId">CUSTODIAN ID NO.</label>
      <input id="custodianId" name="custodian_id" type="text" placeholder="Enter CUSTODIAN ID Here..." required />
      <div class="hint">Example: 01-23456</div>
      <div class="hint-space"></div>
      <label for="custodianPass">CUSTODIAN PASSWORD</label>
      <input id="custodianPass" name="custodian_pass" type="password" placeholder="Enter CUSTODIAN PASSWORD Here..." required/>
      <a href="cforgot_password.php"  class="forgot-link">Forgot Password?</a>
      <div class="button-group">
  <button type="submit" name="login">Login</button>
  <button type="button" id="registerBtn" onclick="window.location.href='cregister_page.php'">Register</button>
</div>
    </form>

    <div class="separator"></div>
    <div class="right-panel">
      <div class="rfid-box" onclick="activateRFID()">
        <div class="rfid-text">Click here then tap your<br>RFID Card To Log In.</div>
        <div class="rfid-image-wrapper">
          <div class="rfid-image-inner">
            <img src="RFIDLogo.png" alt="RFID Logo" />
          </div>
        </div>
      </div>
    </div>
  </div>

  <form action="clogin.php" method="POST" id="rfidForm">
  <input type="text" name="rfid_uid" id="rfidInput" autocomplete="off" />
</form>

  <div class="popup-banner">
    <b>Please Select which User is being logged.</b><br>
    <div class="button-row">
      <a href="clogin_page.php" id="custodianBtn"><button>CUSTODIAN</button>
      <a href="flogin_page.php" id="facultyBtn"><button>FACULTY</button>
      <a href="slogin_page.php" id="studentBtn"><button>STUDENT</button></a>
    </div>
  </div>

  <div class="fade-overlay" id="fadeOverlay"></div>

  <div class="rfid-backdrop" id="rfidBackdrop"></div>
<div class="rfid-popup" id="rfidPopup">
  <span class="rfid-close" onclick="closeRFIDPopup()">×</span>
  <p>Tap your RFID Card now</p>
</div>

  <script>
    const studentBtn = document.getElementById('studentBtn');
    const facultyBtn = document.getElementById('facultyBtn');
    const custodianBtn = document.getElementById('custodianBtn');
    const registerBtn = document.getElementById('registerBtn');
    const fadeOverlay = document.getElementById('fadeOverlay');

    // Student Button
    studentBtn.addEventListener('click', function (e) {
      e.preventDefault();
      fadeOverlay.style.opacity = '1';
      fadeOverlay.style.pointerEvents = 'auto';
      setTimeout(() => {
        window.location.href = studentBtn.getAttribute('href');
      }, 800);
    });

    // Faculty Button
    facultyBtn.addEventListener('click', function (e) {
      e.preventDefault();
      fadeOverlay.style.opacity = '1';
      fadeOverlay.style.pointerEvents = 'auto';
      setTimeout(() => {
        window.location.href = facultyBtn.getAttribute('href');
      }, 800);
    });

    // Custodian Button
    custodianBtn.addEventListener('click', function (e) {
      e.preventDefault();
      fadeOverlay.style.opacity = '1';
      fadeOverlay.style.pointerEvents = 'auto';
      setTimeout(() => {
        window.location.href = custodianBtn.getAttribute('href');
      }, 800);
    });

     const rfidInput = document.getElementById("rfidInput");

function activateRFID() {
  rfidInput.focus();
  document.getElementById("rfidPopup").style.display = "block";
  document.getElementById("rfidBackdrop").style.display = "block";
}

function closeRFIDPopup() {
  document.getElementById("rfidPopup").style.display = "none";
  document.getElementById("rfidBackdrop").style.display = "none";
}


    rfidInput.addEventListener("input", () => {
      if (rfidInput.value.length >= 10) { 
        rfidInput.form.submit();
      }
    });

    window.onload = function() {
      rfidInput.focus();
    }
    
</script>
</body>
</html>
