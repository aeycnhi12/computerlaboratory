<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="cregister_page.css">
</head>
<body>
  <div class="logo-container">
    <img src="AULogo.png" alt="Main Logo" class="logo" />
    <img src="AULogo2.png" alt="Slogan Logo" class="slogan" />
    <img src="AULogo3.png" alt="Additional Slogan" class="sub-slogan" />
  </div>

  <div class="logo-top">
    <img src="AULogo.png" alt="New Main Logo" class="main" />
    <img src="Campus.png" alt="Campus Label" class="campus" />
  </div>

  <div class="center-box">

    <form class="login-left" action="register.php" method="POST">
  <div class="profile-wrapper">
    <div class="profile-wrapper-inner">
      <div class="profile-icon"></div>
    </div>
  </div>

  <div class="form-group-row">
    <div class="form-column">
      <label for="firstname">First Name</label>
      <input type="text" id="firstname" name="firstname" placeholder="Enter First Name" required />

      <label for="user_id">User ID No.</label>
      <input id="user_id" name="user_id" type="text" placeholder="Enter User ID Here..." required />
      <div class="hint">Example: 01-23456</div>

      <label for="user_pass">User Password</label>
      <input id="user_pass" name="user_pass" type="password" placeholder="Enter Password" required />

      <label for="user_type">User Type</label>
      <select name="user_type" id="user_type" required>
        <option value="">-- Select User Type --</option>
        <option value="student">Student</option>
        <option value="faculty">Faculty</option>
        <option value="custodian">Custodian</option>
      </select>
    </div>

    <div class="form-column">
      <label for="lastname">Last Name</label>
      <input type="text" id="lastname" name="lastname" placeholder="Enter Last Name" required />

      <label for="rfid_uid">RFID Card UID</label>
      <input name="rfid_uid" type="text" placeholder="Scan or Enter RFID UID..." required />

      <label for="email">User E-Mail</label>
      <input id="email" name="email" type="email" placeholder="Enter Email" required/>
    </div>
  </div>

<div class="button-row">
  <button type="submit" name="register">Register</button>
  <button type="button" onclick="window.location.href='clogin_page.php'">Log In</button>
</div>
</form>

    <div class="separator"></div>
    <div class="right-panel">
      <div class="rfid-box">
        <div class="rfid-text">Click here then tap your<br>RFID Card To Log In.</div>
        <div class="rfid-image-wrapper">
          <div class="rfid-image-inner">
            <img src="RFIDLogo.png" alt="RFID Logo" />
          </div>
        </div>
      </div>
    </div>
  </div>

</body>
</html>
