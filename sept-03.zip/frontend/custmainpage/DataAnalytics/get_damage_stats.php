<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "fhistory_db";

// Connect to database
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query counts for "damaged", "n/a", "overdue", "good", and "lost"
$sql = "SELECT 
            SUM(CASE WHEN LOWER(condi_tion) = 'damaged' THEN 1 ELSE 0 END) AS damaged_count,
            SUM(CASE WHEN LOWER(condi_tion) = 'n/a' THEN 1 ELSE 0 END) AS na_count,
            SUM(CASE WHEN LOWER(condi_tion) = 'overdue' THEN 1 ELSE 0 END) AS overdue_count,
            SUM(CASE WHEN LOWER(condi_tion) = 'good' THEN 1 ELSE 0 END) AS good_count,
            SUM(CASE WHEN LOWER(condi_tion) = 'lost' THEN 1 ELSE 0 END) AS lost_count
        FROM fhistory";

$result = $conn->query($sql);
$data = [];

if ($result && $row = $result->fetch_assoc()) {
    $data = [
        ['status' => 'Damaged', 'count' => (int)$row['damaged_count']],
        ['status' => 'N/A', 'count' => (int)$row['na_count']],
        ['status' => 'Overdue', 'count' => (int)$row['overdue_count']],
        ['status' => 'Good', 'count' => (int)$row['good_count']],
        ['status' => 'Lost', 'count' => (int)$row['lost_count']]
    ];
}

header('Content-Type: application/json');
echo json_encode($data);

$conn->close();
?>
