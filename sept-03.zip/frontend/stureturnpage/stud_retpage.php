<?php
session_start();
date_default_timezone_set('Asia/Manila');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $_SESSION['id'] = $_POST['id'] ?? '';
    $_SESSION['studentID'] = $_POST['studentID'] ?? '';
    $_SESSION['firstname'] = $_POST['firstname'] ?? '';
    $_SESSION['lastname'] = $_POST['lastname'] ?? '';
    $_SESSION['year'] = $_POST['year'] ?? '';
    $_SESSION['course'] = $_POST['course'] ?? '';
    $_SESSION['equip_rfid'] = $_POST['equip_rfid'] ?? '';
    $_SESSION['serialnum'] = $_POST['serialnum'] ?? '';
    $_SESSION['due_date'] = $_POST['due_date'] ?? '';
    $_SESSION['due_time'] = $_POST['due_time'] ?? '';
    $_SESSION['equipment'] = $_POST['equipment'] ?? '';
    $_SESSION['quantity'] = $_POST['quantity'] ?? '';
    $_SESSION['currentDate'] = $_POST['currentDate'] ?? '';
    $_SESSION['currentTime'] = $_POST['currentTime'] ?? '';
    $_SESSION['status'] = $_POST['status'] ?? '';
    $_SESSION['comment'] = $_POST['comment'] ?? '';
}

$conn = new mysqli("localhost", "root", "", "equip_db");
if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error);
}

$sql = "SELECT name FROM equip WHERE status != 'unavailable'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Return Equipment</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="StudentReturnEquipment.css" />
</head>
<body>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>
<div class="bg-slide bg2"></div>
<div class="bg-slide bg3"></div>
<div class="bg-slide bg4"></div>
  <form action="stu_return_save.php" method="POST" class="center-box" id="returnForm">
    <h1>Return Equipment</h1>
    <h3>Please confirm the return information</h3>

<div class="form-container form-container-top">
  <div class="form-section personal-info">
    <h2 class="section-title">Personal Info</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="id">ID</label>
        <input type="text" id="id" name="id" value="<?= htmlspecialchars($_SESSION['id'] ?? '') ?>" readonly>
      </div>
      <div class="form-group">
        <label for="studentID">Student ID</label>
        <input type="text" id="studentID" name="studentID" value="<?= htmlspecialchars($_SESSION['studentID'] ?? '') ?>" readonly>
      </div>
    </div>
    <div class="form-group-row">
  <div class="form-group">
    <label for="lastname">Last Name</label>
    <input type="text" id="lastname" name="lastname" value="<?= htmlspecialchars($_SESSION['lastname'] ?? '') ?>" readonly>
  </div>
  <div class="form-group">
    <label for="firstname">First Name</label>
    <input type="text" id="firstname" name="firstname" value="<?= htmlspecialchars($_SESSION['firstname'] ?? '') ?>" readonly>
  </div>
</div>
    <div class="form-group-row">
      <div class="form-group">
        <label for="year">Year</label>
        <input type="text" id="year" name="year" value="<?= htmlspecialchars($_SESSION['year'] ?? '') ?>" readonly>
      </div>
      <div class="form-group">
        <label for="course">Course</label>
        <input type="text" id="course" name="course" value="<?= htmlspecialchars($_SESSION['course'] ?? '') ?>" readonly>
      </div>
    </div>
  </div>

  <div class="vertical-separator"></div>

  <div class="form-section item-info">
    <h2 class="section-title">Deadline Info</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="currentDate">Date Borrowed</label>
        <input type="text" id="currentDate" name="currentDate" value="<?= htmlspecialchars($_SESSION['currentDate'] ?? '') ?>" readonly>
      </div>
      <div class="form-group">
        <label for="currentTime">Time Borrowed</label>
        <input type="text" id="currentTime" name="currentTime" value="<?= htmlspecialchars($_SESSION['currentTime'] ?? '') ?>" readonly>
      </div>
    </div>
    <div class="form-group-row">
      <div class="form-group">
        <label for="date_returned">Date Returned</label>
        <input type="text" id="date_returned" name="date_returned" readonly>
      </div>
      <div class="form-group">
        <label for="time_returned">Time Returned</label>
        <input type="text" id="time_returned" name="time_returned" readonly>
      </div>
    </div>
    <div class="form-group-row">
  <div class="form-group">
    <label for="due_date">Due Date</label>
    <input type="text" id="due_date" name="due_date" value="<?= htmlspecialchars($_SESSION['due_date'] ?? '') ?>" readonly>
  </div>
  <div class="form-group">
    <label for="due_time">Due Time</label>
    <input type="text" id="due_time" name="due_time" value="<?= htmlspecialchars($_SESSION['due_time'] ?? '') ?>" readonly>
  </div>
</div>
  </div>
</div>

<div class="form-container">
  <div class="form-section item-info">
    <h2 class="section-title">Equipment Info</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="equip_rfid">Equipment RFID</label>
        <input type="text" id="equip_rfid" name="equip_rfid" value="<?= htmlspecialchars($_SESSION['equip_rfid'] ?? '') ?>" readonly>
      </div>
      <div class="form-group">
        <label for="equipment">Equipment Name</label>
        <input type="text" id="equipment" name="equipment" value="<?= htmlspecialchars($_SESSION['equipment'] ?? '') ?>" readonly>
      </div>
    </div>
    <div class="form-group-row">
      <div class="form-group">
        <label for="serialnum">Serial Number</label>
        <input type="text" name="serialnum" id="serialnum" value="<?= htmlspecialchars($_SESSION['serialnum'] ?? '') ?>" readonly>
      </div>
      <div class="form-group">
        <label for="quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" value="<?= htmlspecialchars($_SESSION['quantity'] ?? '') ?>" readonly>
      </div>
    </div>
  </div>

  <div class="vertical-separator"></div>

  <div class="form-section handler-section">
    <h2 class="section-title">Handler Info</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="handled">Handled By</label>
        <input type="text" id="handled" name="handled" required>
      </div>
      <div class="form-group">
  <label for="condi_tion">Condition</label>
  <select id="condi_tion" name="condi_tion" required>
    <option value="">-- Select Condition --</option>
    <option value="Good" <?= (isset($_SESSION['condi_tion']) && $_SESSION['condi_tion'] === 'Good') ? 'selected' : '' ?>>Good</option>
    <option value="Overdue" <?= (isset($_SESSION['condi_tion']) && $_SESSION['condi_tion'] === 'Overdue') ? 'selected' : '' ?>>Overdue</option>
    <option value="Lost" <?= (isset($_SESSION['condi_tion']) && $_SESSION['condi_tion'] === 'Lost') ? 'selected' : '' ?>>Lost</option>
    <option value="Damaged" <?= (isset($_SESSION['condi_tion']) && $_SESSION['condi_tion'] === 'Damaged') ? 'selected' : '' ?>>Damaged</option>
  </select>
</div>
      <div class="form-group">
        <label for="status">Status</label>
        <select id="status" name="status" required>
          <option value="">-- Select Status --</option>
          <option value="Returned" <?= (isset($_SESSION['status']) && $_SESSION['status'] === 'Returned') ? 'selected' : '' ?>>Returned</option>
          <option value="Unreturned" <?= (isset($_SESSION['status']) && $_SESSION['status'] === 'Unreturned') ? 'selected' : '' ?>>Unreturned</option>
        </select>
      </div>
    </div>
    <div class="form-group comment-group">
      <label for="comment">Comment</label>
      <textarea id="comment" name="comment" required><?= htmlspecialchars($_SESSION['comment'] ?? '') ?></textarea>
    </div>
  </div>
</div>


<div class="rfid-section">
  <p id="tapRFIDText" style="cursor: pointer; color: gray; font-weight: bold; font-style: italic; margin: 0; padding: 0; line-height: 1;">
    Click here then Tap your RFID to Return when finished.
  </p>
  <input type="text" id="rfidInput" name="rfid_uid" style="opacity: 0; position: absolute; pointer-events: none;">
</div>
</form>

<a href="../stureturnpage(1)/stu_returnpage.php" class="back-button">BACK</a>

<script>
  
window.onload = function () {
  const dateInput = document.getElementById('date_returned');
  const timeInput = document.getElementById('time_returned');
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const date = `${year}-${month}-${day}`;

  let hours = now.getHours();
  let minutes = now.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12 || 12;
  minutes = minutes < 10 ? '0' + minutes : minutes;
  const time = `${hours}:${minutes} ${ampm}`;

  dateInput.value = date;
  timeInput.value = time;
};


const backButton = document.querySelector('.back-button');
const fadeOutOverlay = document.getElementById('fadeOutOverlay');

if (backButton) {
  backButton.addEventListener('click', function (e) {
    e.preventDefault();
    fadeOutOverlay.classList.add('active');
    setTimeout(() => {
      window.location.href = backButton.getAttribute('href');
    }, 800);
  });
}

const rfidText = document.getElementById('tapRFIDText');
const rfidInput = document.getElementById('rfidInput');

rfidText.addEventListener('click', function() {
  alert('Please tap your RFID card now.');
  rfidInput.focus();
});

rfidInput.addEventListener('input', function() {
  const rfidValue = this.value.trim();
  if (rfidValue.length >= 10) {
    console.log('RFID detected:', rfidValue);
    document.getElementById('returnForm').submit();
  }
});
</script>
</body>
</html>
