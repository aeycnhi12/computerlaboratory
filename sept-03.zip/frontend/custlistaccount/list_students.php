<?php
$conn = new mysqli("localhost", "root", "", "cust_db");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$result = $conn->query("SELECT * FROM cust WHERE archived = 0");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registered Students</title>
    <link rel="stylesheet" href="list_students.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
<div class="bg2"></div>
<div class="bg3"></div>
<div class="bg4"></div>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>

<div class="container">
  <h2>Registered Students</h2>

  <div class="table-wrapper">
    <table class="equipment-table">
      <thead>
        <tr>
          <th style="width: 30%;">Full Name</th>
          <th style="width: 20%;">Course</th>
          <th style="width: 15%;">Year</th>
          <th style="width: 25%;">Date Registered</th>
          <th style="width: 25%;">Status</th>
          <th style="width: 10%;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) ?></td>
          <td><?= htmlspecialchars($row['course']) ?></td>
          <td><?= htmlspecialchars($row['year']) ?></td>
          <td><?= htmlspecialchars($row['created_at']) ?></td>
          <td class="<?= $row['ban_status'] === 'Active' ? 'status-active' : '' ?>"><?= htmlspecialchars($row['ban_status']) ?></td>
          <td>
            <a href="remove_student.php?id=<?= $row['id'] ?>" class="btn-archive" onclick="return confirm('Are you sure you want to archive this student?')">Archive</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>


    <a href="../custmainpage/custmain_page.php" class="back-button">← Back</a>
</div>

<script>
  window.addEventListener('beforeunload', function () {
    const fadeOutOverlay = document.getElementById('fadeOutOverlay');
    if (fadeOutOverlay) {
      fadeOutOverlay.classList.add('active');
    }
  });

  window.addEventListener('load', function () {
    const fadeInOverlay = document.querySelector('.fade-in-overlay');
    if (fadeInOverlay) {
      fadeInOverlay.style.animation = 'fadeInOverlay 0.8s ease-in-out forwards';
    }
  });

  const backButton = document.querySelector('.back-button');
  const fadeOutOverlay = document.getElementById('fadeOutOverlay');

  if (backButton) {
    backButton.addEventListener('click', (e) => {
      e.preventDefault();
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = backButton.getAttribute('href');
      }, 800);
    });
  }
  
</script>

</body>
</html>

<?php $conn->close(); ?>
