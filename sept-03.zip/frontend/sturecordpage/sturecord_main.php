<?php
session_start();
date_default_timezone_set('Asia/Manila');
$conn = new mysqli("localhost", "root", "", "history_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$firstname = $_SESSION['firstname'] ?? null;
$lastname = $_SESSION['lastname'] ?? null;

if (!$firstname || !$lastname) {
    echo "You are not logged in.";
    exit();
}

$sortField = $_GET['sort_field'] ?? 'currentDate';
$sortOrder = $_GET['sort_order'] ?? 'DESC';

$allowedFields = ['currentDate', 'date_returned'];
$allowedOrder = ['ASC', 'DESC'];

if (!in_array($sortField, $allowedFields)) $sortField = 'currentDate';
if (!in_array($sortOrder, $allowedOrder)) $sortOrder = 'DESC';

$nextOrder = ($sortOrder === 'ASC') ? 'DESC' : 'ASC';

$sql = "SELECT * FROM history 
        WHERE firstname = ? AND lastname = ?
        ORDER BY $sortField $sortOrder";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $firstname, $lastname);
$stmt->execute();
$result = $stmt->get_result();
?>


<!DOCTYPE html>
<html>
<head>
  <title>HISTORY LOGS</title>
  <link rel="stylesheet" href="sturecord.css">
</head>
<body class="animate-bg">
<div class="bg2"></div>
<div class="bg3"></div>
<div class="bg4"></div>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>
<div class="container">
  <h1>HISTORY LOGS</h1>
  <div class="table-container">
    <table class="equipment-table">
      <thead>
  <tr>
    <th style="width: 40px;">ID</th>
    <th style="width: 100px;">Student ID</th>
    <th style="width: 100px;">Last Name</th>
    <th style="width: 120px;">First Name</th>
    <th style="width: 60px;">Year</th>
    <th style="width: 80px;">Course</th>
    <th style="width:160px !important; min-width:160px !important; max-width:160px !important;">
      Date Borrowed
      <a href="?sort_field=currentDate&sort_order=<?= ($sortField === 'currentDate') ? $nextOrder : 'ASC' ?>" style="color:white; text-decoration:none; margin-left:5px;">
        <?= ($sortField === 'currentDate') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
      </a>
    </th>
    <th style="width: 130px;">Time Borrowed</th>
    <th style="width: 130px;">Equipment RFID</th>
    <th style="width: 130px;">Serial Number</th>
    <th style="width: 110px;">Equipment</th>
    <th style="width: 50px;">Qty.</th>
    <th style="width:150px !important; min-width:150px !important; max-width:150px !important;">
      Date Returned
      <a href="?sort_field=date_returned&sort_order=<?= ($sortField === 'date_returned') ? $nextOrder : 'ASC' ?>" style="color:white; text-decoration:none; margin-left:5px;">
        <?= ($sortField === 'date_returned') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
      </a>
    </th>
    <th style="width: 130px;">Time Returned</th>
    <th style="width: 100px;">Due Date</th>
    <th style="width: 100px;">Due Time</th>
    <th style="width: 100px;">Condition</th>
    <th style="width: 100px;">Status</th>
    <th style="width: 100px;">Comment</th>
    <th style="width: 120px;">Handled By</th>
  </tr>
</thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['studentID']) ?></td>
            <td><?= htmlspecialchars($row['lastname']) ?></td>
            <td><?= htmlspecialchars($row['firstname']) ?></td>
            <td><?= htmlspecialchars($row['year']) ?></td>
            <td><?= htmlspecialchars($row['course']) ?></td>
            <td><?= htmlspecialchars($row['currentDate']) ?></td>
            <td><?= htmlspecialchars($row['currentTime']) ?></td>
            <td><?= htmlspecialchars($row['equip_rfid']) ?></td>
            <td><?= htmlspecialchars($row['serialnum']) ?></td>
            <td><?= htmlspecialchars($row['equipment']) ?></td>
            <td><?= htmlspecialchars($row['quantity']) ?></td>
            <td><?= htmlspecialchars($row['date_returned']) ?></td>
            <td><?= htmlspecialchars($row['time_returned']) ?></td>
            <td><?= htmlspecialchars($row['due_date']) ?></td>
            <td><?= htmlspecialchars($row['due_time']) ?></td>
            <td class="<?= $row['condi_tion'] === 'Returned' ? 'condi_tion-lost' : 'condi_tion-damaged' ?>"><?= htmlspecialchars($row['condi_tion']) ?></td>
            <td class="<?= $row['status'] === 'Returned' ? 'status-returned' : 'status-unreturned' ?>"><?= htmlspecialchars($row['status']) ?></td>
            <td><?= htmlspecialchars($row['comment']) ?></td>
            <td><?= htmlspecialchars($row['handled_by']) ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>


<a href="../stumainpage/stumain_page.php" class="back-button">BACK</a>
<script>
  const backButton = document.querySelector('.back-button');
  const fadeOutOverlay = document.getElementById('fadeOutOverlay');

  if (backButton) {
    backButton.addEventListener('click', (e) => {
      e.preventDefault();
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = backButton.getAttribute('href');
      }, 800);
    });
  }

  if (sessionStorage.getItem('fromAddNew') === 'true') {
    const fadeOverlay = document.querySelector('.fade-in-overlay');
    if (fadeOverlay) fadeOverlay.style.display = 'none';
    document.body.classList.remove('animate-bg');
    sessionStorage.removeItem('fromAddNew');
  }
</script>
</body>
</html>
