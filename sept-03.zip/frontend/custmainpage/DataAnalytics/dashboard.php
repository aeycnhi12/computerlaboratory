<!DOCTYPE html>
<html>
<head>
    <title>Lab Analytics Dashboard</title>
    <link rel="stylesheet" href="dashboardstyle.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="dashboard-container">

    <div class="top-buttons">
        <button class="back-button" onclick="location.href='../custmain_page.php'">Back</button>
        <button class="print-button" onclick="window.print()">Download as PDF</button>
    </div>

    <div class="dashboard-header">
    <h1 class="dashboard-title">Dashboard Overview</h1>
    <p class="dashboard-subtitle">Laboratory Borrowing Analytics</p>

    </div>

<div class="stats-container">

    <div class="stat-box student">
        <img src="analytics-assets/student.png" alt="Students">
        <div class="stat-text">
            <h3>Total Students</h3>
            <h2 id="total-students">0</h2>
        </div>
    </div>

    <div class="stat-box faculty">
        <img src="analytics-assets/faculty.png" alt="Faculty">
        <div class="stat-text">
            <h3>Total Faculty</h3>
            <h2 id="total-faculty">0</h2>
        </div>
    </div>

    <div class="stat-box equipment">
        <img src="analytics-assets/equipment.png" alt="Equipment">
        <div class="stat-text">
            <h3>Total Equipment</h3>
            <h2 id="total-equipment">0</h2>
        </div>
    </div>

</div>

<div class="charts-row">

    <div class="chart-box">
        <h2>Most Borrowed Equipments</h2>
        <canvas id="equipmentChart"></canvas>
    </div>

    <div class="chart-box">
        <h2>Items Status Statistics (Faculty)</h2>
        <canvas id="damageChart"></canvas>
    </div>

    <div class="chart-box">
        <h2>Items Status Statistics (Students)</h2>
        <canvas id="damageChartStudent"></canvas>
    </div>

    <div class="chart-box">
        <h2>Course Borrowing Statistics</h2>
        <canvas id="courseChart"></canvas>
    </div>

</div>

<div class="charts-row">
    <div class="chart-box">
        <h2>Borrow Trends per Month (Faculty)</h2>
        <canvas id="facultyTrendChart"></canvas>
    </div>

    <div class="chart-box">
        <h2>Borrow Trends per Month (Students)</h2>
        <canvas id="studentTrendChart"></canvas>
    </div>
</div>



</div>

<script>

// ✅ Fetch student total
fetch('get_total_students.php')
  .then(res => res.json())
  .then(data => {
      document.getElementById('total-students').textContent = data.count;
  });

// ✅ Fetch faculty total
fetch('get_total_faculty.php')
  .then(res => res.json())
  .then(data => {
      document.getElementById('total-faculty').textContent = data.count;
  });

// ✅ Fetch equipment total
fetch('get_total_equipment.php')
  .then(res => res.json())
  .then(data => {
      document.getElementById('total-equipment').textContent = data.count;
  });

//Most Borrowed Equipment Chart
     fetch('get_equipment_data.php')
            .then(response => response.json())
            .then(data => {
                const labels = data.map(item => item.name);       // ✅ updated
                const counts = data.map(item => item.count);      // ✅ updated

                const ctx = document.getElementById('equipmentChart').getContext('2d');
                new Chart(ctx, {
                    type: 'pie',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Most Borrowed Equipment',
                            data: counts,
                            backgroundColor: [
                                '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
                                '#9966FF', '#FF9F40', '#E7E9ED'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    font: {
                                        size: 16,             
                                        family: 'Poppins, Segoe UI, sans-serif'
                                    },
                                    color: 'black',          
                                    //boxWidth: 20,              
                                    //padding: 15,               
                                    usePointStyle: true     
                                }
                            }
                        }
                    }

                });
            })
            .catch(error => {
                console.error("Error fetching chart data:", error);
            });


// Faculty chart
fetch('get_faculty_trends.php')
    .then(response => response.json())
    .then(data => {
        const labels = data.map(item => item.month);
        const counts = data.map(item => item.count);

        new Chart(document.getElementById('facultyTrendChart'), {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Faculty Borrows',
                    data: counts,
                    backgroundColor: '#36A2EB'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true, 
                        labels: {
                            font:{
                                size: 16,
                                family: 'Poppins, Segoe UI, sans-serif'
                                },
                                color: 'black',          
                                usePointStyle: true
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: 'black'
                        }
                    },
                    y: {
                        ticks: {
                            color: 'black'
                        }
                    }
                }
            }

        });
    });

// Student chart
fetch('get_student_trends.php')
    .then(response => response.json())
    .then(data => {
        const labels = data.map(item => item.month);
        const counts = data.map(item => item.count);

        new Chart(document.getElementById('studentTrendChart'), {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Student Borrows',
                    data: counts,
                    backgroundColor: '#FF6384'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true, 
                        labels: {
                            font:{
                                size: 16,
                                family: 'Poppins, Segoe UI, sans-serif'
                                },
                                color: 'black',          
                                usePointStyle: true
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: 'black'
                        }
                    },
                    y: {
                        ticks: {
                            color: 'black'
                        }
                    }
                }
            }
        });
    });

// Damage Statistics
fetch('get_damage_stats.php')
    .then(response => response.json())
    .then(data => {
        const labels = data.map(item => item.status);
        const counts = data.map(item => item.count);

        new Chart(document.getElementById('damageChart'), {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: counts,
                    backgroundColor: ['#FF6384', '#36A2EB', '#26A69A', '#EC407A', '#5C6BC0']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            font:{
                                size: 16,
                                family: 'Poppins, Segoe UI, sans-serif'
                                },
                                color: 'black',          
                                usePointStyle: true
                        }
                    }
                }
            }
        });
    });

// Student Damage Statistics
fetch("get_damage_statsStudent.php")
  .then(response => response.json())
  .then(data => {
    const ctx = document.getElementById("damageChartStudent").getContext("2d");

    new Chart(ctx, {
      type: "pie",
      data: {
        labels: data.map(item => item.status),
        datasets: [{
          label: "Student Condition Statistics",
          data: data.map(item => item.count),
          backgroundColor: [
            "#e74c3c", // Damaged - red
            "#95a5a6", // N/A - gray
            "#f39c12", // Overdue - orange
            "#27ae60", // Good - green
            "#2c3e50"  // Lost - dark gray
          ]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              font: { size: 16, family: "Poppins, Segoe UI, sans-serif" },
              color: "black",
              usePointStyle: true
            }
          }
        }
      }
    });
  });



//most borrowing course
fetch('get_course_stats.php')
  .then(response => response.json())
  .then(data => {
      const labels = data.map(item => item.label);
      const counts = data.map(item => item.count);

      new Chart(document.getElementById('courseChart'), {
          type: 'pie',
          data: {
              labels: labels,
              datasets: [{
                  data: counts,
                  backgroundColor: [
                      '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0',
                      '#9966FF', '#FF9F40', '#C9CBCF', '#7CB342',
                      '#AB47BC', '#26A69A', '#EC407A', '#5C6BC0'
                  ]
              }]
          },
          options: {
              responsive: true,
              plugins: {
                  legend: {
                      position: 'bottom',
                      labels: {
                          font: { size: 16, family: 'Poppins, Segoe UI, sans-serif' },
                          color: 'black',
                          usePointStyle: true
                      }
                  }
              }
          }
      });
  })
  .catch(err => console.error('Course stats fetch error:', err));


</script>

</body>
</html>
