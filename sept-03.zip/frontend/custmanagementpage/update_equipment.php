<?php
$conn = new mysqli('localhost', 'root', '', 'equip_db');
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$id = $_POST['id'];
$serialnum = $_POST['serialnum'];
$equip_rfid = $_POST['equip_rfid'];
$name = $_POST['name'];
$quantity = $_POST['quantity'];
$status = $_POST['status'];

$stmt = $conn->prepare("UPDATE equip SET serialnum = ?, equip_rfid = ?, name=?, quantity=?, status=? WHERE id=?");
$stmt->bind_param("sssisi", $serialnum, $equip_rfid, $name, $quantity, $status, $id);

if ($stmt->execute()) {
  header("Location: custmanage_page.php"); // redirect after success
} else {
  echo "Update failed: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
