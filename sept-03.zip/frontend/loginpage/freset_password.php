<?php
session_start();
$conn = new mysqli("localhost", "root", "", "cust_db");

$message = "";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    $stmt = $conn->prepare("SELECT * FROM cust WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

            $update = $conn->prepare("UPDATE cust SET user_pass = ?, reset_token = NULL WHERE reset_token = ?");
            $update->bind_param("ss", $new_password, $token);
            $update->execute();

            $message = "<div class='success-message'>Password has been reset successfully!</div>";
            header("refresh:2;url=clogin_page.php");
        }
    } else {
        $message = "<div class='error-message'>Invalid or expired token.</div>";
    }
} else {
    $message = "<div class='error-message'>No token provided.</div>";
}
?>

<link rel="stylesheet" href="forgot_password.css">

<div class="container">
    <img src="AULogo.png" alt="AU Logo" class="logo">
    <h2>FACULTY - Reset Password</h2>
    
    <?php if (!empty($message)) echo $message; ?>

    <form method="POST">
        <input type="password" name="new_password" placeholder="Enter New Password" required>
        <button type="submit">Reset Password</button>
    </form>
    <a href="flogin_page.php" class="back-link">← Back to Login</a>
</div>

<div class="wave-container">
    <div class="wave wave-back"></div>
    <div class="wave wave-middle"></div>
    <div class="wave wave-top"></div>
</div>
<div class="circle-container" id="circleContainer"></div>
<script>
  const circleImages = [
    'fpp_circle1.png',
    'fpp_circle2.png',
    'fpp_circle3.png',
    'fpp_circle4.png',
    'fpp_circle5.png',
    'fpp_circle6.png',
    'fpp_circle7.png'
  ];
  function getWeightedSize() {
    const rand = Math.random();
    if (rand < 0.6) return Math.floor(Math.random() * 20) + 20;
    if (rand < 0.9) return Math.floor(Math.random() * 20) + 40;
    return Math.floor(Math.random() * 13) + 60;
  }
  function createFloatingCircle() {
    const container = document.getElementById('circleContainer');
    const circle = document.createElement('div');
    const randomImg = circleImages[Math.floor(Math.random() * circleImages.length)];
    circle.style.backgroundImage = `url('${randomImg}')`;
    const size = getWeightedSize();
    circle.style.width = `${size}px`;
    circle.style.height = `${size}px`;
    const maxLeft = window.innerWidth - size;
    const randomLeft = Math.random() * maxLeft;
    circle.style.left = `${randomLeft}px`;
    const duration = Math.random() * 3 + 4;
    circle.style.animationDuration = `${duration}s`;
    circle.classList.add('floating-circle');
    container.appendChild(circle);
    setTimeout(() => {
      circle.remove();
    }, duration * 1000);
  }
  function spawnFewCircles() {
    const count = Math.random() < 0.7 ? 1 : 2;
    for (let i = 0; i < count; i++) {
      createFloatingCircle();
    }
  }
  function scheduleSpawn() {
    spawnFewCircles();
    setTimeout(scheduleSpawn, Math.random() * 1500 + 2000);
  }
  scheduleSpawn();
</script>
