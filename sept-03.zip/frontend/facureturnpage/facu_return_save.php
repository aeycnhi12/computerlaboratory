<?php
session_start();
date_default_timezone_set('Asia/Manila');


// DB Connections
$fborrowConn = new mysqli("localhost", "root", "", "fborrow_db");
$fhistoryConn = new mysqli("localhost", "root", "", "fhistory_db");
$custConn = new mysqli("localhost", "root", "", "cust_db");

if ($fborrowConn->connect_error || $fhistoryConn->connect_error || $custConn->connect_error) {
    die("DB connection failed.");
}

// Retrieve posted data
$id = $_POST['id'] ?? '';
$condi_tion = $_POST['condi_tion'] ?? '';
$comment = $_POST['comment'] ?? '';
$rfidCode = $_POST['rfid_uid'] ?? '';
$handledBy = $_POST['handled'] ?? '';
$penaltyStatus = ($condi_tion === 'Lost' || $condi_tion === 'Damaged') ? 'Pending' : NULL;
$penaltyAmount = NULL; // Initially null, unless Dean sets a penalty later


if (empty($id)) {
    echo "No borrow ID provided.";
    exit();
}

// Get the borrow record
$getSql = "SELECT * FROM fborrow WHERE id = ?";
$stmt = $fborrowConn->prepare($getSql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Borrow record not found.";
    exit();
}

$fborrowData = $result->fetch_assoc();

// Validate RFID code from cust_db
$rfidStmt = $custConn->prepare("SELECT user_id FROM cust WHERE rfid_uid = ?");
$rfidStmt->bind_param("s", $rfidCode);
$rfidStmt->execute();
$rfidResult = $rfidStmt->get_result();

if ($rfidResult->num_rows === 0) {
    echo "<script>alert('Invalid RFID. Return Failed.'); window.history.back();</script>";
    exit();
}

$rfidData = $rfidResult->fetch_assoc();
$userId = $rfidData['user_id'];  // cust.user_id

// Now compare borrow.studentID with cust.user_id
if ($fborrowData['facultyID'] != $userId) {
    echo "<script>alert('RFID does not match borrower. Return denied.'); window.history.back();</script>";
    exit();
}

// RFID Validated — Proceed to INSERT into history_db
$insertSql = "INSERT INTO fhistory (
    facultyID, lastname, firstname, equip_rfid, serialnum, equipment, quantity, comment, condi_tion, status,
    currentDate, currentTime, date_returned, time_returned, due_date, due_time, handled_by, penalty_status, penalty_amount
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$insertStmt = $fhistoryConn->prepare($insertSql);
$dateReturned = date("Y-m-d");
$timeReturned = date("h:i A"); // 12-hour format
$status = "Returned";

$insertStmt->bind_param("ssssssssssssssssssd",
    $fborrowData['facultyID'],
    $fborrowData['lastname'],
    $fborrowData['firstname'],
    $fborrowData['equip_rfid'],
    $fborrowData['serialnum'],
    $fborrowData['equipment'],
    $fborrowData['quantity'],
    $comment,
    $condi_tion,
    $status,
    $fborrowData['currentDate'],
    $fborrowData['currentTime'],
    $dateReturned,
    $timeReturned,
    $fborrowData['due_date'],
    $fborrowData['due_time'],
    $handledBy,
    $penaltyStatus,
    $penaltyAmount
);

$insertStmt->execute();

// DELETE from borrow table
$deleteSql = "DELETE FROM fborrow WHERE id = ?";
$deleteStmt = $fborrowConn->prepare($deleteSql);
$deleteStmt->bind_param("i", $id);
$deleteStmt->execute();

// Cleanup
$insertStmt->close();
$deleteStmt->close();
$stmt->close();
$rfidStmt->close();
$fborrowConn->close();
$fhistoryConn->close();
$custConn->close();

// Redirect to logs page
header("Location: ../facurecordpage/facurecord_main.php");
exit();
?>
