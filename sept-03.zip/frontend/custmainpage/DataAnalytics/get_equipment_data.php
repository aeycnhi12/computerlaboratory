<?php
$host = "localhost";
$user = "root";
$pass = "";

// Connect to the database that contains the borrow history
$conn = new mysqli($host, $user, $pass, "history_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ✅ Corrected table name used here
$sql = "SELECT equipment AS name, COUNT(*) AS borrow_count
        FROM history
        GROUP BY equipment
        ORDER BY borrow_count DESC";

$result = $conn->query($sql);

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = [
        'name' => $row['name'],
        'count' => (int)$row['borrow_count']
    ];
}

header('Content-Type: application/json');
echo json_encode($data);

$conn->close();
?>
