<?php
// Connect to database
$conn = new mysqli('localhost', 'root', '', 'equip_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if ID is passed via GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete query
    $stmt = $conn->prepare("DELETE FROM equip WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Equipment deleted successfully.'); window.location.href='custmanage_page.php';</script>";
    } else {
        echo "Delete failed: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "<script>alert('Invalid equipment ID.'); window.location.href='custmanage_page.php';</script>";
}

$conn->close();
?>
