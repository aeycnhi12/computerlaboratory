<?php
$conn = new mysqli("localhost", "root", "", "cust_db");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);
$sortField = $_GET['sort_field'] ?? 'lastname';
$sortOrder = $_GET['sort_order'] ?? 'ASC';
$allowedFields = ['lastname'];
$allowedOrder = ['ASC', 'DESC'];

if (!in_array($sortField, $allowedFields)) $sortField = 'lastname';
if (!in_array($sortOrder, $allowedOrder)) $sortOrder = 'ASC';

$nextOrder = ($sortOrder === 'ASC') ? 'DESC' : 'ASC';

$sql = "SELECT * FROM cust WHERE archived = 1 ORDER BY $sortField $sortOrder";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Archived Students</title>
    <link rel="stylesheet" href="archive.css">
</head>
<body>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>

<div class="container-box">
    <h1>Archived Users</h1>
    <table>
        <tr>
            <th>
    Full Name
    <a href="?sort_field=lastname&sort_order=<?= ($sortField === 'lastname') ? $nextOrder : 'ASC' ?>" 
       style="color:white; text-decoration:none; margin-left:5px;">
        <?= ($sortField === 'lastname') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
    </a>
</th>

            <th>Course</th>
            <th>Year</th>
            <th>Restore</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) ?></td>
            <td><?= htmlspecialchars($row['course']) ?></td>
            <td><?= htmlspecialchars($row['year']) ?></td>
            <td>
                <a class="restore-btn" href="restore_student.php?id=<?= $row['id'] ?>" onclick="return confirm('Restore this student?');">Restore</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<a href="list_students.php" class="back-button">← Back</a>

<div class="wave-container">
    <div class="wave wave-back"></div>
    <div class="wave wave-middle"></div>
    <div class="wave wave-top"></div>
</div>
<div class="circle-container" id="circleContainer"></div>

<script>
    const circleImages = [
        'fpp_circle1.png','fpp_circle2.png','fpp_circle3.png',
        'fpp_circle4.png','fpp_circle5.png','fpp_circle6.png','fpp_circle7.png'
    ];

    function getWeightedSize() {
        const rand = Math.random();
        if (rand < 0.6) return Math.floor(Math.random() * 20) + 20;
        if (rand < 0.9) return Math.floor(Math.random() * 20) + 40;
        return Math.floor(Math.random() * 13) + 60;
    }

    function createFloatingCircle() {
        const container = document.getElementById('circleContainer');
        const circle = document.createElement('div');
        const randomImg = circleImages[Math.floor(Math.random() * circleImages.length)];
        circle.style.backgroundImage = `url('${randomImg}')`;
        const size = getWeightedSize();
        circle.style.width = `${size}px`;
        circle.style.height = `${size}px`;
        const maxLeft = window.innerWidth - size;
        circle.style.left = `${Math.random() * maxLeft}px`;
        const duration = Math.random() * 3 + 4;
        circle.style.animationDuration = `${duration}s`;
        circle.classList.add('floating-circle');
        container.appendChild(circle);
        setTimeout(() => { circle.remove(); }, duration * 1000);
    }

    function spawnFewCircles() {
        const count = Math.random() < 0.7 ? 1 : 2;
        for (let i = 0; i < count; i++) createFloatingCircle();
    }

    function scheduleSpawn() {
        spawnFewCircles();
        setTimeout(scheduleSpawn, Math.random() * 1500 + 2000);
    }

    scheduleSpawn();
</script>
</body>
</html>
