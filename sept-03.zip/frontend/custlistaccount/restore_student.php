<?php
$conn = new mysqli("localhost", "root", "", "cust_db");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("UPDATE cust SET archived = 0 WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header("Location: archived_page.php");
        exit();
    } else {
        echo "Error restoring student: " . $stmt->error;
    }
} else {
    echo "Invalid student ID.";
}
?>
