<?php
$servername = "localhost";
$username = "root";
$password = ""; // leave blank if you didn't set a password
$database = "borrow_db"; // change this to your DB name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>


