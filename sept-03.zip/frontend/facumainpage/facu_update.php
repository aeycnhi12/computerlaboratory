<?php
session_start();
$conn = new mysqli("localhost", "root", "", "cust_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$user_id = $_POST['user_id'] ?? null;
$email = $_POST['email'] ?? '';
$user_pass = password_hash($_POST['user_pass'], PASSWORD_DEFAULT);

// Validate required data
if (!$user_id) {
    die(" Missing user ID. Cannot update.");
}

// Optional: Sanitize and validate more here

// Update the database
$sql = "UPDATE cust SET email = ?, user_pass = ? WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $email, $user_pass, $user_id);

if ($stmt->execute()) {
    // Optionally: Add a success flash message here
    header("Location: facu_profile.php?updated=1");
    exit();
} else {
    echo " Error updating profile: " . $stmt->error;
}
?>
