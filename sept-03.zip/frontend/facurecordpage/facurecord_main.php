<?php
session_start();
date_default_timezone_set('Asia/Manila');

$conn = new mysqli("localhost", "root", "", "fhistory_db"); // adjust DB name
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$firstname = $_SESSION['firstname'] ?? null;
$lastname = $_SESSION['lastname'] ?? null;

if (!$firstname || !$lastname) {
    echo "You are not logged in.";
    exit();
}

// Sorting logic
$sortField = $_GET['sort_field'] ?? 'currentDate';
$sortOrder = $_GET['sort_order'] ?? 'DESC';

$allowedFields = ['currentDate', 'date_returned'];
$allowedOrder = ['ASC', 'DESC'];

if (!in_array($sortField, $allowedFields)) $sortField = 'currentDate';
if (!in_array($sortOrder, $allowedOrder)) $sortOrder = 'DESC';

$nextOrder = ($sortOrder === 'ASC') ? 'DESC' : 'ASC';

// Fetch sorted logs handled by the logged-in faculty
$sql = "SELECT * FROM fhistory 
        WHERE firstname = ? AND lastname = ?
        ORDER BY $sortField $sortOrder";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $firstname, $lastname);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <title>HISTORY LOGS</title>
  <link rel="stylesheet" href="facurecord.css">
</head>
<body>
<div class="bg2"></div>
<div class="bg3"></div>
<div class="bg4"></div>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>

<div class="container">
  <h1 class="history-title">HISTORY LOGS</h1>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th style="width: 30px;">ID</th>
          <th>Faculty ID</th>
          <th>Last Name</th>
          <th>First Name</th>
          <th style="width:140px !important; min-width:140px !important; max-width:140px !important;">
            Date Borrowed
            <a href="?sort_field=currentDate&sort_order=<?= ($sortField === 'currentDate') ? $nextOrder : 'ASC' ?>" style="color:white; text-decoration:none; margin-left:5px;">
              <?= ($sortField === 'currentDate') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
            </a>
          </th>
          <th>Time Borrowed</th>
          <th>Equipment RFID</th>
          <th>Serial Number</th>
          <th>Equipment</th>
          <th style="width: 40px;">Qty.</th>
          <th style="width:140px !important; min-width:140px !important; max-width:140px !important;">
            Date Returned
            <a href="?sort_field=date_returned&sort_order=<?= ($sortField === 'date_returned') ? $nextOrder : 'ASC' ?>" style="color:white; text-decoration:none; margin-left:5px;">
              <?= ($sortField === 'date_returned') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
            </a>
          </th>
          <th>Time Returned</th>
          <th>Due Date</th>
          <th>Due Time</th>
          <th style="width: 100px;">Condition</th>
          <th style="width: 80px;">Status</th>
          <th>Comment</th>
          <th>Handled By</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['facultyID']) ?></td>
            <td><?= htmlspecialchars($row['lastname']) ?></td>
            <td><?= htmlspecialchars($row['firstname']) ?></td>
            <td><?= htmlspecialchars($row['currentDate']) ?></td>
            <td><?= htmlspecialchars($row['currentTime']) ?></td>
            <td><?= htmlspecialchars($row['equip_rfid']) ?></td>
            <td><?= htmlspecialchars($row['serialnum']) ?></td>
            <td><?= htmlspecialchars($row['equipment']) ?></td>
            <td><?= htmlspecialchars($row['quantity']) ?></td>
            <td><?= htmlspecialchars($row['date_returned']) ?></td>
            <td><?= htmlspecialchars($row['time_returned']) ?></td>
            <td><?= htmlspecialchars($row['due_date']) ?></td>
            <td><?= htmlspecialchars($row['due_time']) ?></td>
            <td class="<?= $row['condi_tion'] === 'Returned' ? 'condi_tion-lost' : 'condi_tion-damaged' ?>"><?= htmlspecialchars($row['condi_tion']) ?></td>
            <td class="<?= $row['status'] === 'Returned' ? 'status-returned' : 'status-not-returned' ?>"><?= htmlspecialchars($row['status']) ?></td>
            <td><?= htmlspecialchars($row['comment']) ?></td>
            <td><?= htmlspecialchars($row['handled_by']) ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<a href="../facumainpage/facumain_page.php" class="back-button">Back</a>

<script>
  const backButton = document.querySelector('.back-button');
  const fadeOutOverlay = document.getElementById('fadeOutOverlay');
  if (backButton) {
    backButton.addEventListener('click', (e) => {
      e.preventDefault();
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = backButton.getAttribute('href');
      }, 800);
    });
  }
</script>
</body>
</html>
<?php
$stmt->close();
$conn->close();
?>
