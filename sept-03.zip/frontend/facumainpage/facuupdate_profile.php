<?php
session_start();
$conn = new mysqli("localhost", "root", "", "cust_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_FILES['profile_image']) && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    $img_name = basename($_FILES['profile_image']['name']);
    $target_dir = "uploads/";
    $target_file = $target_dir . time() . "_" . $img_name;

    $allowed = ['jpg', 'jpeg', 'png', 'gif'];
    $ext = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if (in_array($ext, $allowed)) {
        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_file)) {
            // ✅ ONLY updating profile_image column
            $sql = "UPDATE cust SET profile_image = ? WHERE user_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $target_file, $user_id);
            $stmt->execute();
        }
    }
}

header("Location: facu_profile.php");
exit();
?>
