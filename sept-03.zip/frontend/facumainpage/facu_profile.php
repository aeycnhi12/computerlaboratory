<?php
session_start();
$conn = new mysqli("localhost", "root", "", "cust_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$faculty_id = $_SESSION['faculty_id'] ?? null;

if (!$faculty_id) {
    die("You are not logged in. Please log in first.");
}

$sql = "SELECT * FROM cust WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $faculty_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    die("No matching user found in database.");
}


$profileImage = !empty($row['profile_image']) ? $row['profile_image'] : 'default_profile.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Faculty Profile</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
  <link href="facuprofile.css" rel="stylesheet" />
</head>
<body>

<div class="fade-in-overlay"></div>
<a href="facumain_page.php" id="backButton" class="back-button">← Back</a>

<div class="page-container">
  <div class="left-panel">
    <div class="faculty-profile">
      <!-- PROFILE IMAGE -->
      <?php
      $profileImage = !empty($row['profile_image']) ? $row['profile_image'] : 'uploads/default_profile.png';
      ?>
      <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="Profile Image" class="profile-image" />

      <!-- IMAGE UPLOAD FORM -->
      <form action="facuupdate_profile.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
        <input type="file" id="profileUpload" name="profile_image" style="display:none" accept="image/*" onchange="this.form.submit()">
        <label for="profileUpload" class="upload-button">＋</label>
      </form>

      <p><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['lastname']); ?></p>
    </div>
  </div>

  <div class="right-panel">
    <div class="white-box">
      <h1>PROFILE INFORMATION</h1>

      <form action="facu_update.php" method="POST" id="profileForm">
        <div class="form-group">
          <label for="facultyNo">Faculty No.</label>
          <input type="text" id="facultyNo" name="user_id" value="<?php echo $row['user_id']; ?>" readonly />
        </div>

        <div class="form-group">
          <label for="facultyEmail">Faculty Email</label>
          <input type="email" id="facultyEmail" name="email" value="<?php echo $row['email']; ?>" disabled />
        </div>

        <div class="form-group">
          <label for="facultyPass">Faculty Pass</label>
          <input type="text" id="facultyPass" name="user_pass" value="<?php echo $row['user_pass']; ?>" disabled />
        </div>

        <div class="button-row">
          <button class="btn edit" type="button">Edit</button>
          <button class="btn save" type="submit">Save</button>
          <button class="btn cancel" type="button">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  const editButton = document.querySelector('.btn.edit');
  const saveButton = document.querySelector('.btn.save');
  const cancelButton = document.querySelector('.btn.cancel');
  const inputs = document.querySelectorAll('input:not([readonly])');

  let originalValues = [];

  saveButton.style.display = 'none';
  cancelButton.style.display = 'none';

  editButton.addEventListener('click', () => {
    originalValues = Array.from(inputs).map(input => input.value);
    inputs.forEach(input => input.disabled = false);
    editButton.style.display = 'none';
    saveButton.style.display = 'inline-block';
    cancelButton.style.display = 'inline-block';
  });

  cancelButton.addEventListener('click', () => {
    const currentValues = Array.from(inputs).map(input => input.value);
    const hasChanged = currentValues.some((val, i) => val !== originalValues[i]);

    if (hasChanged) {
      const confirmCancel = confirm("You have unsaved changes.\nAre you sure you want to cancel?\nAll fields will be cleared?");
      if (!confirmCancel) return;
    }

    inputs.forEach((input, i) => {
      input.value = originalValues[i];
      input.disabled = true;
    });

    saveButton.style.display = 'none';
    cancelButton.style.display = 'none';
    editButton.style.display = 'inline-block';
  });

  const backButton = document.getElementById('backButton');
  const overlay = document.querySelector('.fade-in-overlay');
  const whiteBox = document.querySelector('.white-box');

  if (backButton) {
    backButton.addEventListener('click', function (event) {
      event.preventDefault();
      whiteBox.classList.add('slide-out');
      overlay.classList.add('fade-out');

      setTimeout(() => {
        window.location.href = backButton.getAttribute('href');
      }, 600);
    });
  }
</script>

</body>
</html>
