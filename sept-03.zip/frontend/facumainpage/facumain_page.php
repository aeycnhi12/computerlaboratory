<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// session timeout in seconds (10 mins)
$timeout_duration = 60;

// check if expired
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: ../loginpage/fflogout.php?timeout=1");
    exit();
}

// calculate remaining time without resetting
$elapsed   = isset($_SESSION['LAST_ACTIVITY']) ? (time() - $_SESSION['LAST_ACTIVITY']) : 0;
$remaining = $timeout_duration - $elapsed;

if (!isset($_SESSION['faculty_name'])) {
    header("Location: loginpage/flogin_page.php");
    exit();
}

$facultyName = $_SESSION['faculty_name'];

if (!isset($_SESSION['firstname']) || !isset($_SESSION['lastname'])) {
    $nameParts = explode(' ', $facultyName, 2);
    $_SESSION['firstname'] = $nameParts[0];
    $_SESSION['lastname'] = isset($nameParts[1]) ? $nameParts[1] : '';
}

$firstname = $_SESSION['firstname'];
$lastname = $_SESSION['lastname'];


$conn = new mysqli("localhost", "root", "", "cust_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT profile_image FROM cust WHERE firstname = ? AND lastname = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $firstname, $lastname);
$stmt->execute();
$result = $stmt->get_result();

$profileImage = "uploads/default_profile.png";
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (!empty($row['profile_image'])) {
        $profileImage = $row['profile_image'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Faculty Main</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="FacultyMain.css">
</head>
<body>

  <div class="bg-overlay"></div>
  <div class="fade-in-overlay"></div>
  <div class="fade-out-overlay" id="fadeOutOverlay"></div>
  <div id="extendModal" style="
  display:none;
  position:fixed; top:50%; left:50%; transform:translate(-50%,-50%);
  background:#fff; padding:20px; border-radius:8px;
  box-shadow:0 2px 10px rgba(0,0,0,0.3); z-index:9999; text-align:center;
">
  <p>Your session will expire soon. Do you want to extend?</p>
  <button id="extendBtn">Extend Session</button>
  <button id="logoutNowBtn">Logout</button>
</div>

  <a href="../loginpage/flogin_page.php" class="logout-button" id="logoutBtn">Logout</a>

  <div class="center-box">
    <div class="profile-header">
      <div class="profile-wrapper">
        <div class="profile-wrapper-inner">
          <div class="profile-icon" style="background-image: url('<?php echo htmlspecialchars($profileImage); ?>');"></div>
        </div>
      </div>
      <div class="faculty-name" id="facultyNameDisplay"><?php echo strtoupper(htmlspecialchars($facultyName)); ?></div>
    </div>

    <a href="facu_profile.php" class="menu-link" id="menuBtn">
      <div class="menu-icon">
        <div></div>
        <div></div>
        <div></div>
      </div>
    </a>

    <h1>Click on the option you want to select</h1>
    <div class="action-buttons">
      <button id="borrowBtn">BORROW<br>EQUIPMENT</button>
      <button id="returnBtn">RETURN<br>EQUIPMENT</button>
      <button id="logsBtn"> HISTORY LOGS</button>
    </div>
  </div>

  <script>
    const fadeOutOverlay = document.getElementById('fadeOutOverlay');

    document.getElementById('borrowBtn').addEventListener('click', function () {
      fadeOutOverlay.style.backgroundColor = '#e6f4ff';
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = '../facuborrowpage/facu_borpage.php';
      }, 800);
    });

    document.getElementById('returnBtn').addEventListener('click', function () {
      fadeOutOverlay.style.backgroundColor = '#e6f4ff';
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = '../facureturnpage(1)/facu_returnpage.php';
      }, 800);
    });

    document.getElementById('logsBtn').addEventListener('click', function () {
      fadeOutOverlay.style.backgroundColor = '#e6f4ff';
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = '../facurecordpage/facurecord_main.php';
      }, 800);
    });

    const menuBtn = document.getElementById('menuBtn');
    menuBtn.addEventListener('click', function (e) {
      e.preventDefault();
      fadeOutOverlay.style.backgroundColor = '#264887';
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = menuBtn.getAttribute('href');
      }, 800);
    });

    const logoutBtn = document.getElementById('logoutBtn');
    logoutBtn.addEventListener('click', function (e) {
      e.preventDefault();
      fadeOutOverlay.style.backgroundColor = '#264887';
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = logoutBtn.getAttribute('href');
      }, 800);
    });

    const storedName = localStorage.getItem('facultyName');
    if (storedName) {
      const nameEl = document.getElementById('facultyNameDisplay');
      if (nameEl) nameEl.textContent = storedName.toUpperCase();
    }

    let remaining = <?php echo $remaining; ?>; // from PHP

let countdown = setInterval(() => {
    if (remaining === 30) {
        document.getElementById("extendModal").style.display = "block";
    }

    if (remaining <= 0) {
        clearInterval(countdown);
        window.location.href = "../loginpage/flogout.php?timeout=1";
    }

    remaining--;
}, 1000);

document.getElementById("extendBtn").addEventListener("click", function() {
    fetch("../loginpage/fextend_session.php")
        .then(() => {
            remaining = 60; // or 600 if 10 minutes
            document.getElementById("extendModal").style.display = "none";
        });
});


document.getElementById("logoutNowBtn").addEventListener("click", function() {
    window.location.href = "../loginpage/flogout.php";
});


  </script>
</body>
</html>
