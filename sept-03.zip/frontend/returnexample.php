<?php
session_start();
date_default_timezone_set('Asia/Manila');


$conn = new mysqli("localhost", "root", "", "equip_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
SELECT 
    e.name,
    e.quantity AS total_qty,
    (
        IFNULL((
            SELECT SUM(quantity)
            FROM borrow_db.borrow
            WHERE equipment = e.name AND status = 'Unreturned'
        ), 0) +
        IFNULL((
            SELECT SUM(quantity)
            FROM fborrow_db.fborrow
            WHERE equipment = e.name AND status = 'Unreturned'
        ), 0)
    ) AS total_borrowed,
    (e.quantity - (
        IFNULL((
            SELECT SUM(quantity)
            FROM borrow_db.borrow
            WHERE equipment = e.name AND status = 'Unreturned'
        ), 0) +
        IFNULL((
            SELECT SUM(quantity)
            FROM fborrow_db.fborrow
            WHERE equipment = e.name AND status = 'Unreturned'
        ), 0)
    )) AS available_qty
FROM equip_db.equip e
WHERE e.status = 'Available'
HAVING available_qty > 0
";

$result = $conn->query($sql);


// Name splitting logic
if (isset($_SESSION['student_name'])) {
    $fullName = trim($_SESSION['student_name']);
    $nameParts = explode(' ', $fullName);
    $lastName = array_pop($nameParts); // Get last word = last name
    $firstName = implode(' ', $nameParts); // Rest = first name

    $_SESSION['lastname'] = $lastName;
    $_SESSION['firstname'] = $firstName;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Borrowed Equipment</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="returnexample.css" />
</head>
<body>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>
<div class="bg-slide bg2"></div>
<div class="bg-slide bg3"></div>
<div class="bg-slide bg4"></div>
  <form action="stu_bor_save.php" method="POST" class="center-box" id="returnForm">
    <h1>Borrowed Equipment</h1><br>
    <h3>Please fill the information here</h3>

<div class="form-container">
  <div class="form-section personal-info">
    <h2 class="section-title">Personal Information</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="id">ID</label>
        <input type="text" id="id" name="id" value="<?= htmlspecialchars($_SESSION['id'] ?? '') ?>" readonly>
      </div>
      <div class="form-group">
        <label for="studentID">Student ID</label>
        <input type="text" id="studentID" name="studentID" value="<?= htmlspecialchars($_SESSION['studentID'] ?? '') ?>" readonly>
      </div>
    </div>
    <div class="form-group-row">
  <div class="form-group">
    <label for="lastname">Last Name</label>
    <input type="text" id="lastname" name="lastname" value="<?= htmlspecialchars($_SESSION['lastname'] ?? '') ?>" readonly>
  </div>
  <div class="form-group">
    <label for="firstname">First Name</label>
    <input type="text" id="firstname" name="firstname" value="<?= htmlspecialchars($_SESSION['firstname'] ?? '') ?>" readonly>
  </div>
</div>
    <div class="form-group-row">
      <div class="form-group">
        <label for="year">Year</label>
        <input type="text" id="year" name="year" value="<?= htmlspecialchars($_SESSION['year'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label for="course">Course</label>
        <input type="text" id="course" name="course" value="<?= htmlspecialchars($_SESSION['course'] ?? '') ?>" required>
      </div>
    </div>
  </div>

  <div class="vertical-separator"></div>

  <div class="form-section handler-section">
    <h2 class="section-title">Deadline Information</h2>
    <div class="form-group-row">
      <div class="form-group">
        <label for="handled">Time</label>
        <input type="text" id="currentTime" name="currentTime" value="<?= htmlspecialchars($_SESSION['currentTime'] ?? '') ?>" readonly>
      </div>
       <div class="form-group">
        <label for="currentTime">Date</label>
        <input type="text" id="curretDate" name="currentDate" value="<?= htmlspecialchars($_SESSION['currentDate'] ?? '') ?>" readonly>
      </div>
    </div>
    <div class="form-group comment-group">
      <label for="due_time">Due Time</label>
        <input type="text" id="due_time" name="due_time" value="<?= htmlspecialchars($_SESSION['due_time'] ?? '') ?>" readonly>
      </div>
    <div class="form-group">
        <label for="due_date">Due Date</label>
        <input type="text" id="due_date" name="due_date" value="<?= htmlspecialchars($_SESSION['due_date'] ?? '') ?>" readonly>
    </div>
  </div>
</div>


  <div class="form-section item-info">
    <h2 class="section-title">Equipment Information</h2>
    <div class="form-group-row">
        <div class="form-group">
        <label for="equip_rfid">Equipment RFID</label>
        <input type="text" name="equip_rfid" id="equip_rfid" value="<?= htmlspecialchars($_SESSION['equip_rfid'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label for="equipment">Equipment Name</label>
        <input type="text" id="equipment" name="equipment" value="<?= htmlspecialchars($_SESSION['equipment'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label for="serialnum">Serial Number</label>
        <input type="text" id="serialnum" name="serialnum" value="<?= htmlspecialchars($_SESSION['serialnum'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label for="quantity">Quantity</label>
        <input type="text" id="quantity" name="quantity" value="<?= htmlspecialchars($_SESSION['quantity'] ?? '') ?>" required>
      </div>
    </div>
  </div>

<div class="rfid-section">
  <p id="tapRFIDText" style="cursor: pointer; color: gray; font-weight: bold; font-style: italic; margin: 0; padding: 0; line-height: 1;">
    Click here then Tap your RFID to Return when finished.
  </p>
  <input type="text" id="rfidInput" name="rfid_uid" style="opacity: 0; position: absolute; pointer-events: none;">
</div>
</form>

<a href="../stumainpage/stumain_page.php" class="back-button">BACK</a>

<script>
const backButton = document.querySelector('.back-button');
const fadeOutOverlay = document.getElementById('fadeOutOverlay');

if (backButton) {
  backButton.addEventListener('click', function (e) {
    e.preventDefault();
    fadeOutOverlay.classList.add('active');
    setTimeout(() => {
      window.location.href = backButton.getAttribute('href');
    }, 800);
  });
}

const rfidText = document.getElementById('tapRFIDText');
const rfidInput = document.getElementById('rfidInput');

rfidText.addEventListener('click', function() {
  alert('Please tap your RFID card now.');
  rfidInput.focus();
});

rfidInput.addEventListener('input', function() {
  const rfidValue = this.value.trim();
  if (rfidValue.length >= 10) {
    console.log('RFID detected:', rfidValue);
    document.getElementById('returnForm').submit();
  }
});
</script>
</body>
</html>
