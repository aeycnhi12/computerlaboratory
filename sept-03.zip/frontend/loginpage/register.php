<?php
$cust_conn = new mysqli("localhost", "root", "", "cust_db");
if ($cust_conn->connect_error) {
    die("Connection to cust_db failed: " . $cust_conn->connect_error);
}

if (isset($_POST['register'])) {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $user_id    = $_POST['user_id'];
    $rfid_uid   = $_POST['rfid_uid'];
    $user_pass  = $_POST['user_pass'];
    $email      = $_POST['email'];
    $user_type  = $_POST['user_type'];

    $hashed_password = password_hash($user_pass, PASSWORD_DEFAULT);

    $stmt = $cust_conn->prepare("INSERT INTO cust (user_id, firstname, lastname, rfid_uid, user_pass, email, user_type) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $user_id, $firstname, $lastname, $rfid_uid, $hashed_password, $email, $user_type);


    if ($stmt->execute()) {
        echo "<script>alert('User registered successfully.');</script>";

        if ($user_type === "student") {
            echo "<script>window.location.href='slogin_page.php';</script>";
        } elseif ($user_type === "faculty") {
            echo "<script>window.location.href='flogin_page.php';</script>";
        } elseif ($user_type === "custodian") {
            echo "<script>window.location.href='clogin_page.php';</script>";
        } else {
            echo "<script>alert('Unknown user type.');</script>";
        }

    } else {
        echo "<script>alert('Registration failed: " . $stmt->error . "');</script>";
    }

    $stmt->close();
}

$cust_conn->close();
?>
