<?php
// Connection to borrow_db
$borrowConn = new mysqli("localhost", "root", "", "borrow_db");
if ($borrowConn->connect_error) {
    die("Connection to borrow_db failed: " . $borrowConn->connect_error);
}

// Connection to history_db
$historyConn = new mysqli("localhost", "root", "", "history_db");
if ($historyConn->connect_error) {
    die("Connection to history_db failed: " . $historyConn->connect_error);
}
?>
