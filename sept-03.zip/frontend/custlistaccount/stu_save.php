<?php
session_start();
date_default_timezone_set('Asia/Manila');

// DB Connections
$borrowConn = new mysqli("localhost", "root", "", "borrow_db");
$historyConn = new mysqli("localhost", "root", "", "history_db");
$custConn = new mysqli("localhost", "root", "", "cust_db");

if ($borrowConn->connect_error || $historyConn->connect_error || $custConn->connect_error) {
    die("DB connection failed.");
}

// Retrieve posted data
$id = $_POST['id'] ?? '';
$comment = $_POST['comment'] ?? '';
$rfidCode = $_POST['rfid_uid'] ?? '';

if (empty($id) || empty($rfidCode)) {
    echo "<script>alert('Missing Data. Please try again.'); window.history.back();</script>";
    exit();
}

// Get the borrow record
$getSql = "SELECT * FROM borrow WHERE id = ?";
$stmt = $borrowConn->prepare($getSql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<script>alert('Borrow record not found.'); window.history.back();</script>";
    exit();
}

$borrowData = $result->fetch_assoc();

// Validate RFID code from cust_db (find custodian)
$rfidStmt = $custConn->prepare("SELECT user_id, firstname, lastname FROM cust WHERE rfid_uid = ?");
$rfidStmt->bind_param("s", $rfidCode);
$rfidStmt->execute();
$rfidResult = $rfidStmt->get_result();

if ($rfidResult->num_rows === 0) {
    echo "<script>alert('Invalid RFID. Return Failed.'); window.history.back();</script>";
    exit();
}

$rfidData = $rfidResult->fetch_assoc();
$custUserId = $rfidData['user_id'];
$custFirstName = $rfidData['firstname'];
$custLastName = $rfidData['lastname'];

// Determine if Custodian or Student Tapped
$isCustodian = ($borrowData['studentID'] != $custUserId);

// Handled By: If Custodian tapped, use their name; if Student, use Student's lastname
$handledBy = $isCustodian ? $custLastName : $borrowData['lastname'];

// INSERT into history_db
$insertSql = "INSERT INTO history (
    studentID, lastname, firstname, course, year, equip_rfid, serialnum, equipment, quantity, comment, condi_tion, status,
    currentDate, currentTime, date_returned, time_returned, due_date, due_time, handled_by, penalty_status, penalty_amount
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$insertStmt = $historyConn->prepare($insertSql);
$dateReturned = date("Y-m-d");
$timeReturned = date("h:i A"); // 12-hour format
$status = "Returned";

$insertStmt->bind_param("ssssssssssssssssssssd",
    $borrowData['studentID'],
    $borrowData['lastname'],
    $borrowData['firstname'],
    $borrowData['course'],
    $borrowData['year'],
    $borrowData['equip_rfid'],
    $borrowData['serialnum'],
    $borrowData['equipment'],
    $borrowData['quantity'],
    $comment,
    $borrowData['condi_tion'],
    $status,
    $borrowData['currentDate'],
    $borrowData['currentTime'],
    $borrowData['due_date'],
    $borrowData['due_time'],
    $dateReturned,
    $timeReturned,
    $handledBy,
    $penaltyStatus,
    $penaltyAmount
);

$insertStmt->execute();

// DELETE from borrow table
$deleteSql = "DELETE FROM borrow WHERE id = ?";
$deleteStmt = $borrowConn->prepare($deleteSql);
$deleteStmt->bind_param("i", $id);
$deleteStmt->execute();

// Cleanup
$insertStmt->close();
$deleteStmt->close();
$stmt->close();
$rfidStmt->close();
$borrowConn->close();
$historyConn->close();
$custConn->close();

// Redirect to logs page
echo "<script>alert('Return Successful.'); window.location.href='../custlistaccount/stu_record.php';</script>";
exit();
?>
