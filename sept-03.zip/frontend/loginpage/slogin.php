<?php
session_start();

$conn = new mysqli('localhost', 'root', '', 'cust_db');
if ($conn->connect_error) {
    die('DB connection failed: ' . $conn->connect_error);
}

/* ===================== RFID LOGIN ===================== */
if (isset($_POST['rfid_uid'])) {
    $rfid_uid = trim($_POST['rfid_uid']);

    $sql = "SELECT * FROM cust 
            WHERE rfid_uid LIKE ? 
              AND user_type = 'student' 
              AND archived = 0";   // ✅ Only allow active students
    $rfid_param = '%' . $rfid_uid . '%';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $rfid_param);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        $_SESSION['firstname'] = $row['firstname'];
        $_SESSION['lastname']  = $row['lastname'];
        $_SESSION['student_id'] = $row['user_id'];
        $_SESSION['student_name'] = $row['firstname'] . ' ' . $row['lastname'];

        header('Location: /frontend/stumainpage/stumain_page.php');
        exit();
    } else {
        echo "<script>alert('Access denied. Invalid RFID or account archived.'); history.back();</script>";
    }
    $stmt->close();
}

/* ===================== MANUAL LOGIN ===================== */
if (isset($_POST['login'])) {
    $student_id   = $_POST['student_id'];     
    $student_pass = $_POST['student_pass'];  

    $sql  = "SELECT * FROM cust 
             WHERE user_id = ? 
               AND user_type = 'student' 
               AND archived = 0";   // ✅ Block archived students
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        if (password_verify($student_pass, $row['user_pass'])) {
            $_SESSION['firstname'] = $row['firstname'];
            $_SESSION['lastname']  = $row['lastname'];
            $_SESSION['student_id'] = $row['user_id'];
            $_SESSION['student_name'] = $row['firstname'] . ' ' . $row['lastname'];

            header('Location: /frontend/stumainpage/stumain_page.php');
            exit();
        } else {
            echo "<script>alert('Incorrect password'); history.back();</script>";
        }
    } else {
        echo "<script>alert('Login failed. Either Student ID not found or account is archived.'); history.back();</script>";
    }

    $stmt->close();
}

$conn->close();
?>
