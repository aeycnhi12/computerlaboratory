<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Add New Equipment</title>
  <link rel="stylesheet" href="addnew.css" />
</head>
<body>
<div class="bg5"></div>
<div class="bg6"></div>
<div class="bg7"></div>
<div class="fade-in-overlay"></div>
  <div class="container">
    <h1>Add New Equipment</h1>

    <form action="addequipment.php" method="POST">

      <div class="form-group">
        <label for="equipment_name">Equipment Name</label>
        <input type="text" id="equipment_name" name="equipment_name" placeholder="e.g., Laptop" required>
      </div>

      <div class="form-group">
        <label for="quantity">Quantity</label>
        <input type="number" id="quantity" name="quantity" min="1" placeholder="e.g., 5" required>
      </div>

      <div class="form-group">
        <label for="status">Status</label>
        <select id="status" name="status" required>
          <option value="" disabled selected hidden>Select status</option>
          <option value="Available">Available</option>
          <option value="In Use">In Use</option>
          <option value="Under Repair">Under Repair</option>
          <option value="Broken">Broken</option>
        </select>
      </div>

      <div class="button-group">
        <button type="submit" class="submit-button">Add Equipment</button>
        <a href="custmanage_page.php" class="cancel-button">Cancel</a>
      </div>

    </form>
  </div>
<script>
  document.querySelector('.cancel-button').addEventListener('click', () => {
    sessionStorage.setItem('fromAddNew', 'true');
  });

  document.querySelector('form').addEventListener('submit', () => {
    sessionStorage.setItem('fromAddNew', 'true');
  });
</script>
</body>
</html>
