<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// timeout after 10 mins
$timeout_duration = 600;

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: ../loginpage/flogout.php?timeout=1"); // redirect with timeout flag
    exit();
}

$_SESSION['LAST_ACTIVITY'] = time();
?>