<?php
session_start();
session_unset();
session_destroy();

$msg = "You have been logged out."; // default message
if (isset($_GET['timeout'])) {
    $msg = "Your session expired due to inactivity.";
}

// Redirect back to login with message
header("Location: clogin_page.php?msg=" . urlencode($msg));
exit();
?>