<?php
$conn = new mysqli("localhost", "root", "", "cust_db");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$id = $_GET['id'] ?? null;

if ($id) {
    $stmt = $conn->prepare("UPDATE cust SET archived = 1 WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        header("Location: list_students.php");
        exit();
    } else {
        echo "Error archiving student: " . $stmt->error;
    }
} else {
    echo "Invalid student ID.";
}
?>
