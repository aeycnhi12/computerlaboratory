<?php
session_start();
$conn = new mysqli("localhost", "root", "", "borrow_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$firstname = $_SESSION['firstname'] ?? null;
$lastname = $_SESSION['lastname'] ?? null;

if (!$firstname || !$lastname) {
    echo "You are not logged in.";
    exit();
}

$sql = "SELECT * FROM borrow WHERE firstname = ? AND lastname = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $firstname, $lastname);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
  <title>RETURN LOGS</title>
  <link rel="stylesheet" href="stureturn.css"> 
</head>
<body>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>
<div class="container-box">
  <h1>Return Equipment Logs for Students</h1>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th style="width: 50px;">ID</th>
    <th style="width: 100px;">Student ID</th>
    <th style="width: 120px;">Last Name</th>
    <th style="width: 120px;">First Name</th>
    <th style="width: 60px;">Year</th>
    <th style="width: 60px;">Course</th>
    <th style="width: 120px;">Serial Number</th>
    <th style="width: 130px;">Equipment RFID</th>
    <th style="width: 120px;">Equipment</th>
    <th style="width: 80px;">Quantity</th>
    <th style="width: 90px;">Date Borrowed</th>
    <th style="width: 90px;">Time Borrowed</th>
    <th style="width: 90px;">Due Date</th>
    <th style="width: 90px;">Due Time</th>
    <th style="width: 100px;">Time Remaining</th>
    <th style="width: 100px;">Status</th>
    <th style="width: 100px;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php date_default_timezone_set('Asia/Manila'); // set timezone

while ($row = $result->fetch_assoc()):
    $dueDateTime = strtotime($row['due_date'] . ' ' . $row['due_time']);
    $currentDateTime = time();

    if ($row['status'] === 'Returned') {
        $timeRemaining = 'Returned';
        $statusClass = 'status-returned';
    } elseif ($currentDateTime > $dueDateTime) {
        $timeRemaining = 'Overdue';
        $statusClass = 'status-overdue';
    } else {
        $diff = $dueDateTime - $currentDateTime;
        $hours = floor($diff / 3600);
        $minutes = floor(($diff % 3600) / 60);
        $timeRemaining = "{$hours}h {$minutes}m";
        $statusClass = 'status-unreturned';
    }?>
          <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['studentID']) ?></td>
            <td><?= htmlspecialchars($row['lastname']) ?></td>
            <td><?= htmlspecialchars($row['firstname']) ?></td>
            <td><?= htmlspecialchars($row['year']) ?></td>
            <td><?= htmlspecialchars($row['course']) ?></td>
            <td><?= htmlspecialchars($row['serialnum']) ?></td>
            <td><?= htmlspecialchars($row['equip_rfid']) ?></td>
            <td><?= htmlspecialchars($row['equipment']) ?></td>
            <td><?= htmlspecialchars($row['quantity']) ?></td>
            <td><?= htmlspecialchars($row['currentDate']) ?></td>
            <td><?= htmlspecialchars($row['currentTime']) ?></td>
            <td><?= htmlspecialchars($row['due_date']) ?></td>
            <td><?= htmlspecialchars($row['due_time']) ?></td>
            <td><?= $timeRemaining ?></td>
            <td class="<?= $statusClass ?>"><?= htmlspecialchars($row['status']) ?></td>
            <td>
              <form method="POST" action="../stureturnpage/stud_retpage.php" style="display:inline;">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <input type="hidden" name="studentID" value="<?= $row['studentID'] ?>">
                <input type="hidden" name="firstname" value="<?= $row['firstname'] ?>">
                <input type="hidden" name="lastname" value="<?= $row['lastname'] ?>">
                <input type="hidden" name="year" value="<?= $row['year'] ?>">
                <input type="hidden" name="course" value="<?= $row['course'] ?>">
                <input type="hidden" name="serialnum" value="<?= $row['serialnum'] ?>">
                <input type="hidden" name="equip_rfid" value="<?= $row['equip_rfid'] ?>">
                <input type="hidden" name="equipment" value="<?= $row['equipment'] ?>">
                <input type="hidden" name="quantity" value="<?= $row['quantity'] ?>">
                <input type="hidden" name="currentDate" value="<?= $row['currentDate'] ?>">
                <input type="hidden" name="currentTime" value="<?= $row['currentTime'] ?>">
                <input type="hidden" name="due_date" value="<?= $row['due_date'] ?>">
                <input type="hidden" name="due_time" value="<?= $row['due_time'] ?>">
                <input type="hidden" name="status" value="<?= $row['status'] ?>">
                <button type="submit" class="return-button">Return</button>
              </form>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>


    <a href="../stumainpage/stumain_page.php" class="back-button">← Back</a>

<div class="wave-container">
  <div class="wave wave-back"></div>
  <div class="wave wave-middle"></div>
  <div class="wave wave-top"></div>
</div>
<div class="circle-container" id="circleContainer"></div>
<script>
  const circleImages = [
    'fpp_circle1.png',
    'fpp_circle2.png',
    'fpp_circle3.png',
    'fpp_circle4.png',
    'fpp_circle5.png',
    'fpp_circle6.png',
    'fpp_circle7.png'
  ];
  function getWeightedSize() {
    const rand = Math.random();
    if (rand < 0.6) return Math.floor(Math.random() * 20) + 20;
    if (rand < 0.9) return Math.floor(Math.random() * 20) + 40;
    return Math.floor(Math.random() * 13) + 60;
  }
  function createFloatingCircle() {
    const container = document.getElementById('circleContainer');
    const circle = document.createElement('div');
    const randomImg = circleImages[Math.floor(Math.random() * circleImages.length)];
    circle.style.backgroundImage = `url('${randomImg}')`;
    const size = getWeightedSize();
    circle.style.width = `${size}px`;
    circle.style.height = `${size}px`;
    const maxLeft = window.innerWidth - size;
    const randomLeft = Math.random() * maxLeft;
    circle.style.left = `${randomLeft}px`;
    const duration = Math.random() * 3 + 4;
    circle.style.animationDuration = `${duration}s`;
    circle.classList.add('floating-circle');
    container.appendChild(circle);
    setTimeout(() => {
      circle.remove();
    }, duration * 1000);
  }
  function spawnFewCircles() {
    const count = Math.random() < 0.7 ? 1 : 2;
    for (let i = 0; i < count; i++) {
      createFloatingCircle();
    }
  }
  function scheduleSpawn() {
    spawnFewCircles();
    setTimeout(scheduleSpawn, Math.random() * 1500 + 2000);
  }
  scheduleSpawn();

const backButton = document.querySelector('.back-button');
const fadeOutOverlay = document.getElementById('fadeOutOverlay');

if (backButton) {
  backButton.addEventListener('click', function (e) {
    e.preventDefault();
    fadeOutOverlay.classList.add('active');
    setTimeout(() => {
      window.location.href = backButton.getAttribute('href');
    }, 800);
  });
}

</script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
