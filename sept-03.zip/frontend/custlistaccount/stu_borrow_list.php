<?php
session_start();

$conn = new mysqli("localhost", "root", "", "borrow_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle filter
$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'All';

$sql = "SELECT * FROM borrow";
if ($statusFilter === 'Returned' || $statusFilter === 'Unreturned') {
    $sql .= " WHERE status = '$statusFilter'";
}
$sql .= " ORDER BY currentDate DESC, currentTime DESC";

$result = $conn->query($sql);
// Sorting logic
$sortField = $_GET['sort_field'] ?? 'currentDate';
$sortOrder = $_GET['sort_order'] ?? 'DESC';

$allowedFields = ['studentID', 'lastname', 'currentDate'];
$allowedOrder = ['ASC', 'DESC'];

if (!in_array($sortField, $allowedFields)) $sortField = 'currentDate';
if (!in_array($sortOrder, $allowedOrder)) $sortOrder = 'DESC';

$nextOrder = ($sortOrder === 'ASC') ? 'DESC' : 'ASC';

// Base SQL
$sql = "SELECT * FROM borrow";
if ($statusFilter === 'Returned' || $statusFilter === 'Unreturned') {
    $sql .= " WHERE status = '$statusFilter'";
}
$sql .= " ORDER BY $sortField $sortOrder";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Borrowed Items List</title>
    <link rel="stylesheet" href="stu_borrow_list.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
<div class="bg2"></div>
<div class="bg3"></div>
<div class="bg4"></div>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>

<div class="container">
  <h2>Student Borrowed Equipment List</h2>

  <form method="get">
    <label for="status">Filter by Status:</label>
    <select name="status" id="status" onchange="this.form.submit()">
      <option value="All" <?= $statusFilter === 'All' ? 'selected' : '' ?>>All</option>
      <option value="Returned" <?= $statusFilter === 'Returned' ? 'selected' : '' ?>>Returned</option>
      <option value="Unreturned" <?= $statusFilter === 'Unreturned' ? 'selected' : '' ?>>Unreturned</option>
    </select>
  </form>

<div class="table-container">
  <div class="table-scroll">
    <table class="equipment-table">
       <colgroup>
    <col style="width: 100px;">
    <col style="width: 150px;">
    <col style="width: 50px;">
    <col style="width: 50px;">
    <col style="width: 100px;">
    <col style="width: 100px;">
    <col style="width: 100px;">
    <col style="width: 60px;"> 
    <col style="width: 100px;">
    <col style="width: 100px;">
    <col style="width: 100px;">
    <col style="width: 100px;">
    <col style="width: 100px;"> 
    <col style="width: 100px;"> 
    <col style="width: 100px;">
  </colgroup>
      <thead>
  <tr>
    <th>
      Student ID
      <a href="?sort_field=studentID&sort_order=<?= ($sortField === 'studentID') ? $nextOrder : 'ASC' ?>&status=<?= urlencode($statusFilter) ?>"
         style="color:white; text-decoration:none; margin-left:5px;">
         <?= ($sortField === 'studentID') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
      </a>
    </th>
    <th>
      Full Name
      <a href="?sort_field=lastname&sort_order=<?= ($sortField === 'lastname') ? $nextOrder : 'ASC' ?>&status=<?= urlencode($statusFilter) ?>"
         style="color:white; text-decoration:none; margin-left:5px;">
         <?= ($sortField === 'lastname') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
      </a>
    </th>
    <th >Course</th>
    <th>Year</th>
    <th>Equipment RFID</th>
    <th>Serial Number</th>
    <th>Equipment</th>
    <th>Qty.</th>
    <th>
      Date Borrowed
      <a href="?sort_field=currentDate&sort_order=<?= ($sortField === 'currentDate') ? $nextOrder : 'ASC' ?>&status=<?= urlencode($statusFilter) ?>"
         style="color:white; text-decoration:none; margin-left:5px;">
         <?= ($sortField === 'currentDate') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
      </a>
    </th>
    <th>Time Borrowed</th>
    <th>Due Date</th>
    <th>Due Time</th>
    <th>Time Remaining</th>
    <th>Status</th>
    <th>Action</th>
  </tr>
</thead>

      <tbody>
        <?php date_default_timezone_set('Asia/Manila'); // set timezone

while ($row = $result->fetch_assoc()):
    $dueDateTime = strtotime($row['due_date'] . ' ' . $row['due_time']);
    $currentDateTime = time();

    if ($row['status'] === 'Returned') {
        $timeRemaining = 'Returned';
        $statusClass = 'status-returned';
    } elseif ($currentDateTime > $dueDateTime) {
        $timeRemaining = 'Overdue';
        $statusClass = 'status-overdue';
    } else {
        $diff = $dueDateTime - $currentDateTime;
        $hours = floor($diff / 3600);
        $minutes = floor(($diff % 3600) / 60);
        $timeRemaining = "{$hours}h {$minutes}m";
        $statusClass = 'status-unreturned';
    } ?>
        <tr>
          <td><?= htmlspecialchars($row['studentID']) ?></td>
          <td><?= htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) ?></td>
          <td><?= htmlspecialchars($row['course']) ?></td>
          <td><?= htmlspecialchars($row['year']) ?></td>
          <td><?= htmlspecialchars($row['equip_rfid']) ?></td>
          <td><?= htmlspecialchars($row['serialnum']) ?></td>
          <td><?= htmlspecialchars($row['equipment']) ?></td>
          <td><?= htmlspecialchars($row['quantity']) ?></td>
          <td><?= htmlspecialchars($row['currentDate']) ?></td>
          <td><?= htmlspecialchars($row['currentTime']) ?></td>
          <td><?= htmlspecialchars($row['due_date']) ?></td>
          <td><?= htmlspecialchars($row['due_time']) ?></td>
          <td><?= $timeRemaining ?></td>
          <td class="<?= $statusClass ?>"><?= htmlspecialchars($row['status']) ?></td>
          <td> 

          <form method="POST" action="../custlistaccount/scust_retpage.php" style="display:inline;">
            <input type="hidden" name="id" value="<?= $row['id'] ?>">
            <input type="hidden" name="studentID" value="<?= $row['studentID'] ?>">
            <input type="hidden" name="firstname" value="<?= $row['firstname'] ?>">
            <input type="hidden" name="lastname" value="<?= $row['lastname'] ?>">
            <input type="hidden" name="year" value="<?= $row['year'] ?>">
            <input type="hidden" name="course" value="<?= $row['course'] ?>">
            <input type="hidden" name="equip_rfid" value="<?= $row['equip_rfid'] ?>">
            <input type="hidden" name="serialnum" value="<?= $row['serialnum'] ?>">
            <input type="hidden" name="equipment" value="<?= $row['equipment'] ?>">
            <input type="hidden" name="quantity" value="<?= $row['quantity'] ?>">
            <input type="hidden" name="currentDate" value="<?= $row['currentDate'] ?>">
            <input type="hidden" name="currentTime" value="<?= $row['currentTime'] ?>">
            <input type="hidden" name="due_date" value="<?= $row['due_date'] ?>">
            <input type="hidden" name="due_time" value="<?= $row['due_time'] ?>">
            <input type="hidden" name="status" value="<?= $row['status'] ?>">

          <button type="submit" class="deleteBtn" <?= $row['status'] === 'returned' ? 'disabled' : '' ?>>
          Return
        </button>
          </form>
        </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>


  <a href="../custmainpage/custswitch.php" class="back-button">BACK</a>
</div>

<script>
  window.addEventListener('beforeunload', function () {
    const fadeOutOverlay = document.getElementById('fadeOutOverlay');
    if (fadeOutOverlay) {
      fadeOutOverlay.classList.add('active');
    }
  });

  window.addEventListener('load', function () {
    const fadeInOverlay = document.querySelector('.fade-in-overlay');
    if (fadeInOverlay) {
      fadeInOverlay.style.animation = 'fadeInOverlay 0.8s ease-in-out forwards';
    }
  });

  const backButton = document.querySelector('.back-button');
  const fadeOutOverlay = document.getElementById('fadeOutOverlay');

  if (backButton) {
    backButton.addEventListener('click', (e) => {
      e.preventDefault();
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = backButton.getAttribute('href');
      }, 800);
    });
  }
</script>
</body>
</html>

<?php $conn->close(); ?>
