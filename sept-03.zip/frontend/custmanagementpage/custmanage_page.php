<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'equip_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$borrowConn = new mysqli('localhost', 'root', '', 'borrow_db');
if ($borrowConn->connect_error) {
    die("Borrow DB Connection failed: " . $borrowConn->connect_error);
}

$facultyborrowConn = new mysqli('localhost', 'root', '', 'fborrow_db');
if ($facultyborrowConn->connect_error) {
    die("Faculty Borrow DB Connection failed: " . $facultyborrowConn->connect_error);
}

// Sorting logic
$sortField = $_GET['sort_field'] ?? 'date_added';
$sortOrder = $_GET['sort_order'] ?? 'DESC';

// Allow sorting by ID and Date Added
$allowedFields = ['id', 'date_added'];
$allowedOrder = ['ASC', 'DESC'];

if (!in_array($sortField, $allowedFields)) $sortField = 'date_added';
if (!in_array($sortOrder, $allowedOrder)) $sortOrder = 'DESC';

$nextOrder = ($sortOrder === 'ASC') ? 'DESC' : 'ASC';

// Fetch equipment data with sorting
$sql = "SELECT * FROM equip ORDER BY $sortField $sortOrder";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Manage Equipment</title>
  <link rel="stylesheet" href="custmanage.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body class="animate-bg">
<div class="bg2"></div>
<div class="bg3"></div>
<div class="bg4"></div>
<div class="fade-in-overlay"></div>
<div class="fade-out-overlay" id="fadeOutOverlay"></div>
  <div class="container">
    <h1>Manage Equipment</h1>
    <div class="top-bar">
      <button id="openAddModal" class="add-button">+ Add New Equipment</button>
    </div>
    <div class="table-container">
      <table class="equipment-table">
        <thead>
          <tr>
            <th>ID<a href="?sort_field=id&sort_order=<?= ($sortField === 'id') ? $nextOrder : 'ASC' ?>" 
     style="color:white; text-decoration:none; margin-left:5px;">
    <?= ($sortField === 'id') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
  </a>
</th>
            <th>Serial Number</th>
            <th>RFID ID</th>
            <th>Equipment Name</th>
            <th>Quantity</th>
            <th>Status</th>
            <th> Date Added <a href="?sort_field=date_added&sort_order=<?= ($sortField === 'date_added') ? $nextOrder : 'ASC' ?>" 
     style="color:white; text-decoration:none; margin-left:5px;">
    <?= ($sortField === 'date_added') ? ($sortOrder === 'ASC' ? '▲' : '▼') : '⇅' ?>
  </a>
</th>
            <th>Action</th>
          </tr>
        </thead>
      </table>
      <div class="table-body-scroll">
        <table class="equipment-table">
          <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()):
                $equipName = $conn->real_escape_string($row['name']);
                $borrowedQty = 0;

                // Student Borrowed Items
                $borrowSql = "SELECT SUM(quantity) AS total_borrowed 
                              FROM borrow
                              WHERE equipment = '$equipName' AND status = 'Unreturned'";
                $borrowResult = $borrowConn->query($borrowSql);
                if ($borrowResult && $borrowRow = $borrowResult->fetch_assoc()) {
                    $borrowedQty += (int)$borrowRow['total_borrowed'];
                }

                // Faculty Borrowed Items
                $facultyBorrowSql = "SELECT SUM(quantity) AS total_borrowed 
                                    FROM fborrow
                                    WHERE equipment = '$equipName' AND status = 'Unreturned'";
                $facultyBorrowResult = $facultyborrowConn->query($facultyBorrowSql);
                if ($facultyBorrowResult && $facultyBorrowRow = $facultyBorrowResult->fetch_assoc()) {
                    $borrowedQty += (int)$facultyBorrowRow['total_borrowed'];
                }

                // Calculate Available Quantity
                $availableQty = $row['quantity'] - $borrowedQty;
                $currentStatus = ($availableQty > 0) ? "Available" : "Unavailable";
              ?>
            <tr>
              <td><?php echo $row['id']; ?></td>
              <td><?php echo htmlspecialchars($row['serialnum']); ?></td>
              <td><?php echo htmlspecialchars($row['equip_rfid']); ?></td>
              <td><?php echo htmlspecialchars($row['name']); ?></td>
              <td><?php echo $availableQty; ?></td>
              <td class="<?php echo strtolower($currentStatus); ?>-status"><?php echo $currentStatus; ?></td>
              <td><?php echo $row['date_added']; ?></td>
              <td>
                <button class="editBtn"
                  data-id="<?php echo $row['id']; ?>"
                  data-name="<?php echo htmlspecialchars($row['name']); ?>"
                  data-quantity="<?php echo $availableQty; ?>"
                  data-status="<?php echo $currentStatus; ?>"
                  data-rfid="<?php echo htmlspecialchars($row['equip_rfid']); ?>"
                  data-serial="<?php echo htmlspecialchars($row['serialnum']); ?>">
                  Edit
                </button>


                <a href="delete_equip.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure?')">
                  <button class="deleteBtn">Delete</button>
                </a>
              </td>
            </tr>
            <?php endwhile; ?>
            <?php else: ?>
            <tr>
              <td colspan="6">No equipment found.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

      <!-- ADD EQUIPMENT MODAL START -->
    <div id="addNewModal" class="modal">
      <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Add New Equipment</h2>
        <form id="addNewForm" action="addequipment.php" method="POST">
          <div class="modal-form-group">
            <label for="equip_rfid">RFID Number</label>
            <input type="text" id="equip_rfid" name="equip_rfid" required>
          </div>
          <div class="modal-form-group">
            <label for="serialnum">Serial Number</label>
            <input type="text" id="serialnum" name="serialnum" required>
          </div>
          <div class="modal-form-group">
            <label for="equipment_name">Equipment Name</label>
            <input type="text" id="equipment_name" name="equipment_name" required>
          </div>
          <div class="modal-form-group">
            <label for="quantity">Quantity</label>
            <input type="number" id="quantity" name="quantity" min="1" required>
          </div>
          <div class="modal-form-group">
            <label for="status">Status</label>
            <select id="status" name="status" required>
              <option value="" disabled selected hidden>Select status</option>
              <option value="Available">Available</option>
            </select>
          </div>
          <div style="text-align: center; margin-top: 20px;">
            <button type="submit" class="save-btn">Add Equipment</button>
          </div>
        </form>
      </div>
    </div>

    <!-- ADD EQUIP MODAL END -->
    <!-- EDIT EQUIP MODAL START -->

    <div id="editModal" class="modal">
      <div class="modal-content">
        <span class="closeBtn">&times;</span>
        <h2>Edit Equipment</h2>
        <form id="editForm" action="update_equipment.php" method="POST">
          <input type="hidden" name="id" id="editId">
          <div class="modal-form-group">
            <div class="modal-row">
              <div class="modal-field">
                <label for="editSerial">Serial Number:</label>
                <input type="text" name="serialnum" id="editSerial" class="modal-input" required>
              </div>
              <div class="modal-field">
                <label for="editRFID">RFID UID:</label>
                <input type="text" name="equip_rfid" id="editRFID" class="modal-input" required>
              </div>
              <div class="modal-field">
                <label for="editName">Equipment Name:</label>
                <input type="text" name="name" id="editName" class="modal-input" required>
              </div>
              <div class="modal-field">
                <label for="editQuantity">Quantity:</label>
                <input type="number" name="quantity" id="editQuantity" class="modal-input" required>
              </div>
            </div>
            <div class="modal-row">
              <div class="modal-field" style="flex: 1;">
               <input type="hidden" name="currentStatus" id="editCurrentStatus">
                <select name="status" id="editStatus" class="modal-select" required>
                  <option value="Available">Available</option>
                  <option value="Unavailable">Unavailable</option>
                  <option value="In Use">In Use</option>
                  <option value="Under Repair">Under Repair</option>
                  <option value="Broken">Broken</option>
                </select>
              </div>
            </div>
          </div>
          <div style="text-align: center; margin-top: 20px;">
            <button type="submit" class="save-btn">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  </div>

    <!-- EDIT EQUIP MODAL END -->

<a href="../custmainpage/custmain_page.php" class="action-button back-button">BACK</a>

<script>
  const backButton = document.querySelector('.back-button');
  const fadeOutOverlay = document.getElementById('fadeOutOverlay');

  if (backButton) {
    backButton.addEventListener('click', (e) => {
      e.preventDefault();
      fadeOutOverlay.classList.add('active');
      setTimeout(() => {
        window.location.href = backButton.getAttribute('href');
      }, 800);
    });
  }

  const modal = document.getElementById('editModal');
  const closeBtn = document.querySelector('.closeBtn');
  const editButtons = document.querySelectorAll('.editBtn');

  editButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      document.getElementById('editId').value = this.dataset.id;
      document.getElementById('editRFID').value = this.dataset.rfid;
      document.getElementById('editSerial').value = this.dataset.serial;
      document.getElementById('editName').value = this.dataset.name;
      document.getElementById('editQuantity').value = this.dataset.quantity;
      document.getElementById('editStatus').value = this.dataset.status;
      document.getElementById('editCurrentStatus').value = this.dataset.status;  // <-- Add this line
      modal.style.display = 'block';
    });
});


  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  const addNewModal = document.getElementById('addNewModal');
  const openAddModalBtn = document.getElementById('openAddModal');
  const closeAddBtn = addNewModal.querySelector('.close');

  openAddModalBtn.addEventListener('click', function() {
    addNewModal.style.display = 'block';
  });

  closeAddBtn.addEventListener('click', function() {
    addNewModal.style.display = 'none';
  });

  window.addEventListener('click', function(event) {
    if (event.target === addNewModal) {
      addNewModal.style.display = 'none';
    }
  });


  window.onclick = function(e) {
    if (e.target === modal) {
      modal.style.display = 'none';
    }
  };

  if (sessionStorage.getItem('fromAddNew') === 'true') {
    const fadeOverlay = document.querySelector('.fade-in-overlay');
    if (fadeOverlay) fadeOverlay.style.display = 'none';
    document.body.classList.remove('animate-bg');
    sessionStorage.removeItem('fromAddNew');
  }
</script>
</body>
</html>
<?php 
$borrowConn->close();
$facultyborrowConn->close();
$conn->close();
?>
