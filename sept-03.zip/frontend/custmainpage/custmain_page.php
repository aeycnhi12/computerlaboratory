<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// session timeout in seconds (10 mins)
$timeout_duration = 60;

// check if expired
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: ../loginpage/clogout.php?timeout=1");
    exit();
}

// calculate remaining time without resetting
$elapsed   = isset($_SESSION['LAST_ACTIVITY']) ? (time() - $_SESSION['LAST_ACTIVITY']) : 0;
$remaining = $timeout_duration - $elapsed;


if (!isset($_SESSION['custodian_name'])) {
    header("Location: loginpage/clogin_page.php");
    exit();
}

$custodianName = $_SESSION['custodian_name'];

if (!isset($_SESSION['firstname']) || !isset($_SESSION['lastname'])) {
    $nameParts = explode(' ', $custodianName, 2);
    $_SESSION['firstname'] = $nameParts[0];
    $_SESSION['lastname'] = isset($nameParts[1]) ? $nameParts[1] : '';
}

$firstname = $_SESSION['firstname'];
$lastname = $_SESSION['lastname'];


$conn = new mysqli("localhost", "root", "", "cust_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT profile_image FROM cust WHERE firstname = ? AND lastname = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $firstname, $lastname);
$stmt->execute();
$result = $stmt->get_result();

$profileImage = "frontend/custmainpage/uploads/default_profile.png";
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (!empty($row['profile_image'])) {
        $profileImage = $row['profile_image'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Custodian Main Page</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet" />
  <link href="CustodianMain.css" rel="stylesheet">
</head>
<body>

<div class="bg-overlay"></div>
  <div class="fade-in-overlay"></div>
  <div class="fade-out-overlay" id="fadeOutOverlay"></div>
<div id="extendModal" style="
  display:none;
  position:fixed; top:50%; left:50%; transform:translate(-50%,-50%);
  background:#fff; padding:20px; border-radius:8px;
  box-shadow:0 2px 10px rgba(0,0,0,0.3); z-index:9999; text-align:center;
">
  <p>Your session will expire soon. Do you want to extend?</p>
  <button id="extendBtn">Extend Session</button>
  <button id="logoutNowBtn">Logout</button>
</div>

<a href="../loginpage/clogin_page.php" class="logout-button" id="logoutBtn">Logout</a>
  <div class="center-box">
    <div class="profile-header">
      <div class="profile-wrapper">
        <div class="profile-wrapper-inner">
            <div class="profile-icon" style="background-image: url('<?php echo htmlspecialchars($profileImage); ?>');"></div>
        </div>
      </div>
      <div class="custodian-name"><?php echo strtoupper(htmlspecialchars($custodianName)); ?></div>
    </div>
<a href="cust_profile.php" class="menu-link" id="menuBtn">
  <div class="menu-icon">
    <div></div>
    <div></div>
    <div></div>
  </div>
</a>

    <h1>Click on the option you want to select</h1>
    
<div class="button-grid">
  
  <div class="tooltip">
    <button id="manageBtn">MANAGE<br>EQUIPMENT</button>
    <span class="tooltiptext">Add, edit, or remove equipment details.</span>
  </div>

  <div class="tooltip">
    <button id="stulistBtn">BORROWED<br>ITEM</button>
    <span class="tooltiptext">View items currently borrowed by students or faculty.</span>
  </div>

  <div class="tooltip">
    <button id="listBtn">USER<br>LIST</button> 
    <span class="tooltiptext">Manage student and faculty accounts.</span>
  </div>

  <div class="tooltip">
    <button id="archivedBtn">ARCHIVED<br>USERS</button>
    <span class="tooltiptext">View and restore archived records.</span>
  </div>

  <div class="tooltip">
    <button id="penalBtn">PENALTY<br>MANAGEMENT</button>
    <span class="tooltiptext">Track and manage penalties for overdue items.</span>
  </div>

  <div class="tooltip">
    <button id="itemsBtn">ITEM<br>ANALYTIC</button>
    <span class="tooltiptext">Analyze equipment usage trends and data.</span>
  </div>
</div>

    

  </div>

  <script>
    const storedName = localStorage.getItem('custodianName');
    if (storedName) {
      document.getElementById('custodianNameDisplay').textContent = storedName.toUpperCase();
    }

    const fadeOutOverlay = document.getElementById('fadeOutOverlay');

  function setFadeOverlay(color, redirectUrl) {
    fadeOutOverlay.style.backgroundColor = color;
    fadeOutOverlay.classList.add('active');
    setTimeout(() => {
      window.location.href = redirectUrl;
    }, 800);
  }

  document.getElementById('manageBtn').addEventListener('click', () => {
    setFadeOverlay('#e6f4ff', '../custmanagementpage/custmanage_page.php');
  });

  document.getElementById('listBtn').addEventListener('click', () => {
    setFadeOverlay('#e6f4ff', '../custlistaccount/list_students.php');
  });

  document.getElementById('stulistBtn').addEventListener('click', () => {
    setFadeOverlay('#264887', '../custmainpage/custswitch.php');
  });

  document.getElementById('penalBtn').addEventListener('click', () => {
    setFadeOverlay('#264887', '../custmainpage/penalty_management.php');
  });

  document.getElementById('archivedBtn').addEventListener('click', () => {
    setFadeOverlay('#264887', '../custlistaccount/archived_page.php');
  });

  document.getElementById('itemsBtn').addEventListener('click', () => {
    setFadeOverlay('#264887', '../custmainpage/DataAnalytics/dashboard.php');
  });

  document.getElementById('logoutBtn').addEventListener('click', (e) => {
    e.preventDefault();
    setFadeOverlay('#264887', e.target.href);
  });

  const menuBtn = document.getElementById('menuBtn');
  menuBtn.addEventListener('click', (e) => {
    e.preventDefault();
    setFadeOverlay('#264887', menuBtn.getAttribute('href'));
  });

let remaining = <?php echo $remaining; ?>; // from PHP

let countdown = setInterval(() => {
    if (remaining === 30) {
        document.getElementById("extendModal").style.display = "block";
    }

    if (remaining <= 0) {
        clearInterval(countdown);
        window.location.href = "../loginpage/clogout.php?timeout=1";
    }

    remaining--;
}, 1000);

document.getElementById("extendBtn").addEventListener("click", function() {
    fetch("../loginpage/cextend_session.php")
        .then(() => {
            remaining = 60; // or 600 if 10 minutes
            document.getElementById("extendModal").style.display = "none";
        });
});


document.getElementById("logoutNowBtn").addEventListener("click", function() {
    window.location.href = "../loginpage/clogout.php";
});


  </script>
</body>
</html>
