<?php
session_start();

$conn = new mysqli("localhost", "root", "", "cust_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- Filters ---
$filterCondition = $_GET['condi_tion'] ?? '';
$search = $_GET['search'] ?? '';

$conditionSql = $filterCondition ? "AND condi_tion = '$filterCondition'" : "";
$searchSql = $search ? "AND (firstname LIKE '%$search%' OR lastname LIKE '%$search%' OR equipment LIKE '%$search%' OR id LIKE '%$search%')" : "";

// --- Student History ---
$historyConn = new mysqli("localhost", "root", "", "history_db");
$studentHistory = $historyConn->query("
    SELECT *, 'student' as userType 
    FROM history 
    WHERE penalty_status IN ('Paid','Replace Item','Disregarded','Removed') 
    $conditionSql $searchSql
");
$historyConn->close();

// --- Faculty History ---
$fhistoryConn = new mysqli("localhost", "root", "", "fhistory_db");
$facultyHistory = $fhistoryConn->query("
    SELECT *, 'faculty' as userType 
    FROM fhistory 
    WHERE penalty_status IN ('Paid','Replace Item','Disregarded','Removed') 
    $conditionSql $searchSql
");
$fhistoryConn->close();

$allHistory = array_merge(
    $studentHistory ? $studentHistory->fetch_all(MYSQLI_ASSOC) : [],
    $facultyHistory ? $facultyHistory->fetch_all(MYSQLI_ASSOC) : []
);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Penalty History</title>
  <link rel="stylesheet" href="penaltymanagement.css">
</head>
<body>
  <div class="container-box">
    <h1>Penalty History</h1>

    <div class="filter-wrapper">
      <form method="GET" id="filterForm" style="margin-bottom:10px;">
          <label for="conditionFilter">Filter by Condition:</label>
          <select name="condi_tion" id="conditionFilter" onchange="this.form.submit();">
              <option value="" <?= (!$filterCondition ? 'selected' : '') ?>>All</option>
              <option value="Good" <?= ($filterCondition=='Good'?'selected':'') ?>>Good</option>
              <option value="Overdue" <?= ($filterCondition=='Overdue'?'selected':'') ?>>Overdue</option>
              <option value="Damaged" <?= ($filterCondition=='Damaged'?'selected':'') ?>>Damaged</option>
              <option value="Lost" <?= ($filterCondition=='Lost'?'selected':'') ?>>Lost</option>
          </select>

          <input type="text" name="search" placeholder="Search by Name, Equipment, ID" 
                 value="<?= htmlspecialchars($search) ?>" style="margin-left:10px;">
          <button type="submit">Search</button>
      </form>
    </div>

    <table border="1">
      <tr>
        <th>ID</th>
        <th>User Type</th>
        <th>Name</th>
        <th>Equipment</th>
        <th>Condition</th>
        <th>Comment</th>
        <th>Penalty Amount</th>
        <th>Status</th>
      </tr>
      <?php if (count($allHistory) > 0): ?>
        <?php foreach ($allHistory as $row): ?>
          <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= ucfirst($row['userType']) ?></td>
            <td><?= htmlspecialchars($row['firstname'] . ' ' . $row['lastname']) ?></td>
            <td><?= htmlspecialchars($row['equipment']) ?></td>
            <td><?= htmlspecialchars($row['condi_tion']) ?></td>
            <td><?= htmlspecialchars($row['comment']) ?></td>
            <td><?= $row['penalty_amount'] ? '₱' . number_format($row['penalty_amount'], 2) : '---' ?></td>
            <td><?= htmlspecialchars($row['penalty_status']) ?></td>
          </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr><td colspan="8">No history records found.</td></tr>
      <?php endif; ?>
    </table>
  </div>

  <a href="penalty_management.php" class="back-button">← Back to Management</a>
</body>
</html>
